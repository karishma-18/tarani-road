import {
  users, User, InsertUser,
  complaints, Complaint, InsertComplaint,
  collaborations, Collaboration, InsertCollaboration,
  collaborationMembers, CollaborationMember, InsertCollaborationMember,
  ratings, Rating, InsertRating,
  roadRatings, RoadRating, InsertRoadRating
} from "@shared/schema";

// Interface for storage methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Complaint methods
  createComplaint(complaint: InsertComplaint): Promise<Complaint>;
  getComplaint(id: number): Promise<Complaint | undefined>;
  getComplaintsByUser(userId: number): Promise<Complaint[]>;
  getComplaintsByStatus(status: string): Promise<Complaint[]>;
  getComplaintsByLocation(latitude: number, longitude: number, radius: number): Promise<Complaint[]>;
  updateComplaintStatus(id: number, status: string, officialId?: number): Promise<Complaint | undefined>;
  getAllComplaints(): Promise<Complaint[]>;
  
  // Collaboration methods
  createCollaboration(collaboration: InsertCollaboration): Promise<Collaboration>;
  getCollaboration(id: number): Promise<Collaboration | undefined>;
  getUserCollaborations(userId: number): Promise<Collaboration[]>;
  getAllCollaborations(): Promise<Collaboration[]>;
  
  // Collaboration members methods
  addMemberToCollaboration(member: InsertCollaborationMember): Promise<CollaborationMember>;
  getCollaborationMembers(collaborationId: number): Promise<CollaborationMember[]>;
  
  // Rating methods
  createRating(rating: InsertRating): Promise<Rating>;
  getRatingsByComplaint(complaintId: number): Promise<Rating[]>;
  getRatingsByOfficial(officialId: number): Promise<Rating[]>;
  
  // Road rating methods
  createRoadRating(roadRating: InsertRoadRating): Promise<RoadRating>;
  getRoadRatingsByRoad(roadName: string): Promise<RoadRating[]>;
  getAllRoadRatings(): Promise<RoadRating[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private usersData: Map<number, User>;
  private complaintsData: Map<number, Complaint>;
  private collaborationsData: Map<number, Collaboration>;
  private collaborationMembersData: Map<number, CollaborationMember>;
  private ratingsData: Map<number, Rating>;
  private roadRatingsData: Map<number, RoadRating>;
  
  private userIdCounter: number;
  private complaintIdCounter: number;
  private collaborationIdCounter: number;
  private collaborationMemberIdCounter: number;
  private ratingIdCounter: number;
  private roadRatingIdCounter: number;

  constructor() {
    this.usersData = new Map();
    this.complaintsData = new Map();
    this.collaborationsData = new Map();
    this.collaborationMembersData = new Map();
    this.ratingsData = new Map();
    this.roadRatingsData = new Map();
    
    this.userIdCounter = 1;
    this.complaintIdCounter = 1;
    this.collaborationIdCounter = 1;
    this.collaborationMemberIdCounter = 1;
    this.ratingIdCounter = 1;
    this.roadRatingIdCounter = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersData.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const newUser: User = { ...user, id, points: 0, createdAt };
    this.usersData.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersData.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.usersData.values());
  }

  // Complaint methods
  async createComplaint(complaint: InsertComplaint): Promise<Complaint> {
    const id = this.complaintIdCounter++;
    const createdAt = new Date();
    const newComplaint: Complaint = { ...complaint, id, createdAt, updatedAt: null, completedAt: null };
    this.complaintsData.set(id, newComplaint);
    return newComplaint;
  }

  async getComplaint(id: number): Promise<Complaint | undefined> {
    return this.complaintsData.get(id);
  }

  async getComplaintsByUser(userId: number): Promise<Complaint[]> {
    return Array.from(this.complaintsData.values()).filter(
      (complaint) => complaint.userId === userId
    );
  }

  async getComplaintsByStatus(status: string): Promise<Complaint[]> {
    return Array.from(this.complaintsData.values()).filter(
      (complaint) => complaint.status === status
    );
  }

  async getComplaintsByLocation(latitude: number, longitude: number, radius: number): Promise<Complaint[]> {
    // Simple implementation - in a real application we would use geospatial queries
    // This simplified version just gets complaints within a square box
    const latDiff = radius / 111; // Approximate 1 degree = 111km
    const lonDiff = radius / (111 * Math.cos(latitude * Math.PI / 180));
    
    return Array.from(this.complaintsData.values()).filter(
      (complaint) => {
        const latDistance = Math.abs(complaint.latitude - latitude);
        const lonDistance = Math.abs(complaint.longitude - longitude);
        return latDistance < latDiff && lonDistance < lonDiff;
      }
    );
  }

  async updateComplaintStatus(id: number, status: string, officialId?: number): Promise<Complaint | undefined> {
    const complaint = await this.getComplaint(id);
    if (!complaint) return undefined;
    
    const updatedAt = new Date();
    let completedAt = complaint.completedAt;
    
    if (status === 'resolved' && complaint.status !== 'resolved') {
      completedAt = new Date();
    }
    
    const updatedComplaint: Complaint = { 
      ...complaint, 
      status, 
      updatedAt, 
      completedAt,
      officialId: officialId !== undefined ? officialId : complaint.officialId 
    };
    
    this.complaintsData.set(id, updatedComplaint);
    return updatedComplaint;
  }

  async getAllComplaints(): Promise<Complaint[]> {
    return Array.from(this.complaintsData.values());
  }

  // Collaboration methods
  async createCollaboration(collaboration: InsertCollaboration): Promise<Collaboration> {
    const id = this.collaborationIdCounter++;
    const createdAt = new Date();
    const newCollaboration: Collaboration = { ...collaboration, id, createdAt };
    this.collaborationsData.set(id, newCollaboration);
    return newCollaboration;
  }

  async getCollaboration(id: number): Promise<Collaboration | undefined> {
    return this.collaborationsData.get(id);
  }

  async getUserCollaborations(userId: number): Promise<Collaboration[]> {
    return Array.from(this.collaborationsData.values()).filter(
      (collaboration) => collaboration.createdBy === userId
    );
  }

  async getAllCollaborations(): Promise<Collaboration[]> {
    return Array.from(this.collaborationsData.values());
  }

  // Collaboration members methods
  async addMemberToCollaboration(member: InsertCollaborationMember): Promise<CollaborationMember> {
    const id = this.collaborationMemberIdCounter++;
    const joinedAt = new Date();
    const newMember: CollaborationMember = { ...member, id, joinedAt };
    this.collaborationMembersData.set(id, newMember);
    return newMember;
  }

  async getCollaborationMembers(collaborationId: number): Promise<CollaborationMember[]> {
    return Array.from(this.collaborationMembersData.values()).filter(
      (member) => member.collaborationId === collaborationId
    );
  }

  // Rating methods
  async createRating(rating: InsertRating): Promise<Rating> {
    const id = this.ratingIdCounter++;
    const createdAt = new Date();
    const newRating: Rating = { ...rating, id, createdAt };
    this.ratingsData.set(id, newRating);
    return newRating;
  }

  async getRatingsByComplaint(complaintId: number): Promise<Rating[]> {
    return Array.from(this.ratingsData.values()).filter(
      (rating) => rating.complaintId === complaintId
    );
  }

  async getRatingsByOfficial(officialId: number): Promise<Rating[]> {
    return Array.from(this.ratingsData.values()).filter(
      (rating) => rating.officialId === officialId
    );
  }

  // Road rating methods
  async createRoadRating(roadRating: InsertRoadRating): Promise<RoadRating> {
    const id = this.roadRatingIdCounter++;
    const createdAt = new Date();
    const newRoadRating: RoadRating = { ...roadRating, id, createdAt };
    this.roadRatingsData.set(id, newRoadRating);
    return newRoadRating;
  }

  async getRoadRatingsByRoad(roadName: string): Promise<RoadRating[]> {
    return Array.from(this.roadRatingsData.values()).filter(
      (roadRating) => roadRating.roadName === roadName
    );
  }

  async getAllRoadRatings(): Promise<RoadRating[]> {
    return Array.from(this.roadRatingsData.values());
  }
}

// Export storage instance
export const storage = new MemStorage();
