import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertComplaintSchema, insertCollaborationSchema, insertCollaborationMemberSchema, insertRatingSchema, insertRoadRatingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      // Check if user already exists
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.get("/api/users", async (_req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  // Complaint routes
  app.post("/api/complaints", async (req: Request, res: Response) => {
    try {
      const complaintData = insertComplaintSchema.parse(req.body);
      const complaint = await storage.createComplaint(complaintData);
      
      // Add points to user for reporting
      const user = await storage.getUser(complaintData.userId);
      if (user) {
        await storage.updateUser(user.id, { points: (user.points || 0) + 5 });
      }
      
      res.status(201).json(complaint);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid complaint data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create complaint" });
    }
  });

  app.get("/api/complaints/:id", async (req: Request, res: Response) => {
    try {
      const complaintId = parseInt(req.params.id);
      const complaint = await storage.getComplaint(complaintId);
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      res.json(complaint);
    } catch (error) {
      res.status(500).json({ message: "Failed to get complaint" });
    }
  });

  app.get("/api/complaints", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const status = req.query.status as string | undefined;
      
      if (userId) {
        const complaints = await storage.getComplaintsByUser(userId);
        return res.json(complaints);
      }
      
      if (status) {
        const complaints = await storage.getComplaintsByStatus(status);
        return res.json(complaints);
      }
      
      const complaints = await storage.getAllComplaints();
      res.json(complaints);
    } catch (error) {
      res.status(500).json({ message: "Failed to get complaints" });
    }
  });

  app.patch("/api/complaints/:id/status", async (req: Request, res: Response) => {
    try {
      const complaintId = parseInt(req.params.id);
      const { status, officialId } = req.body;
      
      const complaint = await storage.getComplaint(complaintId);
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      
      const updatedComplaint = await storage.updateComplaintStatus(
        complaintId, 
        status, 
        officialId ? parseInt(officialId) : undefined
      );
      
      // If complaint is resolved, add points to the user
      if (status === 'resolved' && complaint.status !== 'resolved') {
        const user = await storage.getUser(complaint.userId);
        if (user) {
          await storage.updateUser(user.id, { points: (user.points || 0) + 10 });
        }
      }
      
      res.json(updatedComplaint);
    } catch (error) {
      res.status(500).json({ message: "Failed to update complaint status" });
    }
  });

  app.get("/api/complaints/location", async (req: Request, res: Response) => {
    try {
      const latitude = parseFloat(req.query.latitude as string);
      const longitude = parseFloat(req.query.longitude as string);
      const radius = parseFloat(req.query.radius as string || "5"); // Default 5km radius
      
      if (isNaN(latitude) || isNaN(longitude)) {
        return res.status(400).json({ message: "Invalid location parameters" });
      }
      
      const complaints = await storage.getComplaintsByLocation(latitude, longitude, radius);
      res.json(complaints);
    } catch (error) {
      res.status(500).json({ message: "Failed to get complaints by location" });
    }
  });

  // Collaboration routes
  app.post("/api/collaborations", async (req: Request, res: Response) => {
    try {
      const collaborationData = insertCollaborationSchema.parse(req.body);
      const collaboration = await storage.createCollaboration(collaborationData);
      res.status(201).json(collaboration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid collaboration data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create collaboration" });
    }
  });

  app.get("/api/collaborations/:id", async (req: Request, res: Response) => {
    try {
      const collaborationId = parseInt(req.params.id);
      const collaboration = await storage.getCollaboration(collaborationId);
      if (!collaboration) {
        return res.status(404).json({ message: "Collaboration not found" });
      }
      res.json(collaboration);
    } catch (error) {
      res.status(500).json({ message: "Failed to get collaboration" });
    }
  });

  app.get("/api/collaborations", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      if (userId) {
        const collaborations = await storage.getUserCollaborations(userId);
        return res.json(collaborations);
      }
      
      const collaborations = await storage.getAllCollaborations();
      res.json(collaborations);
    } catch (error) {
      res.status(500).json({ message: "Failed to get collaborations" });
    }
  });

  app.post("/api/collaborations/:id/members", async (req: Request, res: Response) => {
    try {
      const collaborationId = parseInt(req.params.id);
      const { userId } = req.body;
      
      const collaboration = await storage.getCollaboration(collaborationId);
      if (!collaboration) {
        return res.status(404).json({ message: "Collaboration not found" });
      }
      
      const memberData = insertCollaborationMemberSchema.parse({
        collaborationId,
        userId
      });
      
      const member = await storage.addMemberToCollaboration(memberData);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid member data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add member to collaboration" });
    }
  });

  app.get("/api/collaborations/:id/members", async (req: Request, res: Response) => {
    try {
      const collaborationId = parseInt(req.params.id);
      const members = await storage.getCollaborationMembers(collaborationId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to get collaboration members" });
    }
  });

  // Rating routes
  app.post("/api/ratings", async (req: Request, res: Response) => {
    try {
      const ratingData = insertRatingSchema.parse(req.body);
      const rating = await storage.createRating(ratingData);
      res.status(201).json(rating);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid rating data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create rating" });
    }
  });

  app.get("/api/ratings/complaints/:complaintId", async (req: Request, res: Response) => {
    try {
      const complaintId = parseInt(req.params.complaintId);
      const ratings = await storage.getRatingsByComplaint(complaintId);
      res.json(ratings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get complaint ratings" });
    }
  });

  app.get("/api/ratings/officials/:officialId", async (req: Request, res: Response) => {
    try {
      const officialId = parseInt(req.params.officialId);
      const ratings = await storage.getRatingsByOfficial(officialId);
      res.json(ratings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get official ratings" });
    }
  });

  // Road rating routes
  app.post("/api/road-ratings", async (req: Request, res: Response) => {
    try {
      const roadRatingData = insertRoadRatingSchema.parse(req.body);
      const roadRating = await storage.createRoadRating(roadRatingData);
      res.status(201).json(roadRating);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid road rating data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create road rating" });
    }
  });

  app.get("/api/road-ratings/:roadName", async (req: Request, res: Response) => {
    try {
      const roadName = req.params.roadName;
      const roadRatings = await storage.getRoadRatingsByRoad(roadName);
      res.json(roadRatings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get road ratings" });
    }
  });

  app.get("/api/road-ratings", async (_req: Request, res: Response) => {
    try {
      const roadRatings = await storage.getAllRoadRatings();
      res.json(roadRatings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get road ratings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
