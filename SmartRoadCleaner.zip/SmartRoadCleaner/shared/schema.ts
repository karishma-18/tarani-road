import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  fullName: text("full_name"),
  userType: text("user_type").notNull().default("user"),
  profilePicture: text("profile_picture"),
  points: integer("points").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const complaints = pgTable("complaints", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  location: text("location").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  status: text("status").notNull().default("pending"),
  officialId: integer("official_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  completedAt: timestamp("completed_at"),
});

export const collaborations = pgTable("collaborations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  date: timestamp("date").notNull(),
  createdBy: integer("created_by").notNull(),
  capacity: integer("capacity").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const collaborationMembers = pgTable("collaboration_members", {
  id: serial("id").primaryKey(),
  collaborationId: integer("collaboration_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  complaintId: integer("complaint_id").notNull(),
  userId: integer("user_id").notNull(),
  officialId: integer("official_id"),
  rating: integer("rating").notNull(),
  review: text("review"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const roadRatings = pgTable("road_ratings", {
  id: serial("id").primaryKey(),
  roadName: text("road_name").notNull(),
  userId: integer("user_id").notNull(),
  rating: integer("rating").notNull(),
  review: text("review"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  phone: true,
  fullName: true,
  userType: true,
  profilePicture: true,
});

export const insertComplaintSchema = createInsertSchema(complaints).pick({
  userId: true,
  title: true,
  description: true,
  imageUrl: true,
  location: true,
  latitude: true,
  longitude: true,
  status: true,
  officialId: true,
});

export const insertCollaborationSchema = createInsertSchema(collaborations).pick({
  title: true,
  description: true,
  location: true,
  date: true,
  createdBy: true,
  capacity: true,
});

export const insertCollaborationMemberSchema = createInsertSchema(collaborationMembers).pick({
  collaborationId: true,
  userId: true,
});

export const insertRatingSchema = createInsertSchema(ratings).pick({
  complaintId: true,
  userId: true,
  officialId: true,
  rating: true,
  review: true,
});

export const insertRoadRatingSchema = createInsertSchema(roadRatings).pick({
  roadName: true,
  userId: true,
  rating: true,
  review: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertComplaint = z.infer<typeof insertComplaintSchema>;
export type Complaint = typeof complaints.$inferSelect;

export type InsertCollaboration = z.infer<typeof insertCollaborationSchema>;
export type Collaboration = typeof collaborations.$inferSelect;

export type InsertCollaborationMember = z.infer<typeof insertCollaborationMemberSchema>;
export type CollaborationMember = typeof collaborationMembers.$inferSelect;

export type InsertRating = z.infer<typeof insertRatingSchema>;
export type Rating = typeof ratings.$inferSelect;

export type InsertRoadRating = z.infer<typeof insertRoadRatingSchema>;
export type RoadRating = typeof roadRatings.$inferSelect;
