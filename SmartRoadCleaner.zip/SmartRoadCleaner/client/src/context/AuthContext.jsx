import { createContext, useState, useEffect } from 'react';
import { auth } from '../lib/firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import { apiRequest } from '../lib/queryClient';
import { queryClient } from '../lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Get user data from backend
          const response = await fetch(`/api/users?email=${firebaseUser.email}`);
          
          if (response.ok) {
            const users = await response.json();
            if (users.length > 0) {
              setUser(users[0]);
            } else {
              // If user doesn't exist in backend, create one
              console.log('User not found in backend, creating new user');
            }
          } else {
            console.error('Failed to fetch user data');
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Register with email and password
  const register = async (userData) => {
    try {
      // Create user in Firebase
      const userCredential = await createUserWithEmailAndPassword(
        auth, 
        userData.email, 
        userData.password
      );
      
      // Update profile in Firebase
      await updateProfile(userCredential.user, {
        displayName: userData.fullName
      });

      // Create user in our backend
      const newUser = {
        username: userData.email.split('@')[0],
        email: userData.email,
        password: 'firebase-auth', // Placeholder as we're using Firebase auth
        fullName: userData.fullName,
        phone: userData.phone,
        userType: userData.userType || 'user'
      };

      const response = await apiRequest('POST', '/api/users', newUser);
      const createdUser = await response.json();
      
      setUser(createdUser);
      
      // Invalidate users query to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      return createdUser;
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: "Registration Error",
        description: error.message,
        variant: "destructive"
      });
      throw error;
    }
  };

  // Login with email and password
  const login = async (email, password, userType = 'user') => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      
      // Check if the user has the correct userType
      const response = await fetch(`/api/users?email=${email}`);
      if (response.ok) {
        const users = await response.json();
        if (users.length > 0) {
          const user = users[0];
          
          if (user.userType !== userType) {
            // If userType doesn't match, sign out and throw an error
            await signOut(auth);
            throw new Error(`You're not authorized as a ${userType}. Please use the correct login option.`);
          }
          
          setUser(user);
          return user;
        }
      }
      
      throw new Error('Failed to fetch user data after login');
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "Login Error",
        description: error.message,
        variant: "destructive"
      });
      throw error;
    }
  };

  // Logout
  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      queryClient.clear();
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        title: "Logout Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  // Update user data
  const updateUserData = async (userId, userData) => {
    try {
      const response = await apiRequest('PATCH', `/api/users/${userId}`, userData);
      const updatedUser = await response.json();
      
      setUser(updatedUser);
      
      // Invalidate users query to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      return updatedUser;
    } catch (error) {
      console.error('Update user error:', error);
      toast({
        title: "Update Error",
        description: error.message,
        variant: "destructive"
      });
      throw error;
    }
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        loading,
        register,
        login,
        logout,
        updateUserData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
