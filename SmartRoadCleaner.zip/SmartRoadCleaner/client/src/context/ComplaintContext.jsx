import { createContext, useState } from 'react';
import { apiRequest } from '../lib/queryClient';
import { storage } from '../lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { queryClient } from '../lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export const ComplaintContext = createContext();

export const ComplaintProvider = ({ children }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // Submit a new complaint
  const submitComplaint = async (complaintData, image) => {
    setIsSubmitting(true);
    
    try {
      let imageUrl = null;
      
      // Upload image to Firebase Storage if provided
      if (image) {
        const storageRef = ref(storage, `complaints/${Date.now()}_${image.name}`);
        const snapshot = await uploadBytes(storageRef, image);
        imageUrl = await getDownloadURL(snapshot.ref);
      }
      
      // Create complaint with image URL
      const complaintWithImage = {
        ...complaintData,
        imageUrl
      };
      
      const response = await apiRequest('POST', '/api/complaints', complaintWithImage);
      const newComplaint = await response.json();
      
      // Invalidate complaints queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/complaints'] });
      
      toast({
        title: "Complaint Submitted",
        description: "Your complaint has been submitted successfully.",
      });
      
      return newComplaint;
    } catch (error) {
      console.error('Submit complaint error:', error);
      toast({
        title: "Submission Error",
        description: error.message || "Failed to submit complaint",
        variant: "destructive"
      });
      throw error;
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update complaint status
  const updateComplaintStatus = async (complaintId, status, officialId) => {
    try {
      const response = await apiRequest('PATCH', `/api/complaints/${complaintId}/status`, { 
        status, 
        officialId 
      });
      const updatedComplaint = await response.json();
      
      // Invalidate complaints queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/complaints'] });
      
      toast({
        title: "Status Updated",
        description: `Complaint status updated to ${status}.`,
      });
      
      return updatedComplaint;
    } catch (error) {
      console.error('Update status error:', error);
      toast({
        title: "Update Error",
        description: error.message || "Failed to update complaint status",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Submit a rating for a complaint
  const submitRating = async (ratingData) => {
    try {
      const response = await apiRequest('POST', '/api/ratings', ratingData);
      const newRating = await response.json();
      
      // Invalidate ratings queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/ratings'] });
      
      toast({
        title: "Rating Submitted",
        description: "Your rating has been submitted successfully.",
      });
      
      return newRating;
    } catch (error) {
      console.error('Submit rating error:', error);
      toast({
        title: "Rating Error",
        description: error.message || "Failed to submit rating",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Submit a road rating
  const submitRoadRating = async (roadRatingData) => {
    try {
      const response = await apiRequest('POST', '/api/road-ratings', roadRatingData);
      const newRoadRating = await response.json();
      
      // Invalidate road ratings queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/road-ratings'] });
      
      toast({
        title: "Road Rating Submitted",
        description: "Your road rating has been submitted successfully.",
      });
      
      return newRoadRating;
    } catch (error) {
      console.error('Submit road rating error:', error);
      toast({
        title: "Rating Error",
        description: error.message || "Failed to submit road rating",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Create a new collaboration event
  const createCollaboration = async (collaborationData) => {
    try {
      const response = await apiRequest('POST', '/api/collaborations', collaborationData);
      const newCollaboration = await response.json();
      
      // Invalidate collaborations queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/collaborations'] });
      
      toast({
        title: "Event Created",
        description: "Your cleanup event has been created successfully.",
      });
      
      return newCollaboration;
    } catch (error) {
      console.error('Create collaboration error:', error);
      toast({
        title: "Creation Error",
        description: error.message || "Failed to create cleanup event",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Join a collaboration event
  const joinCollaboration = async (collaborationId, userId) => {
    try {
      const response = await apiRequest('POST', `/api/collaborations/${collaborationId}/members`, { userId });
      const memberData = await response.json();
      
      // Invalidate collaborations queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/collaborations'] });
      
      toast({
        title: "Joined Event",
        description: "You have joined the cleanup event successfully.",
      });
      
      return memberData;
    } catch (error) {
      console.error('Join collaboration error:', error);
      toast({
        title: "Join Error",
        description: error.message || "Failed to join cleanup event",
        variant: "destructive"
      });
      throw error;
    }
  };

  return (
    <ComplaintContext.Provider 
      value={{ 
        isSubmitting,
        submitComplaint,
        updateComplaintStatus,
        submitRating,
        submitRoadRating,
        createCollaboration,
        joinCollaboration
      }}
    >
      {children}
    </ComplaintContext.Provider>
  );
};
