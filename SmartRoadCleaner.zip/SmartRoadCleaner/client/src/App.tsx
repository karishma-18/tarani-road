import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./context/AuthContext";
import { ComplaintProvider } from "./context/ComplaintContext";

// Pages
import HomePage from "./pages/HomePage";
import UserDashboard from "./pages/UserDashboard";
import OfficialDashboard from "./pages/OfficialDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/not-found";
import Chatbot from "./components/Layout/Chatbot";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/user-dashboard/*" component={UserDashboard} />
      <Route path="/official-dashboard/*" component={OfficialDashboard} />
      <Route path="/admin-dashboard/*" component={AdminDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ComplaintProvider>
          <Router />
          <Toaster />
          <Chatbot />
        </ComplaintProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
