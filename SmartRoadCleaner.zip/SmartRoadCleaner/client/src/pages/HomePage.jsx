import { useEffect } from 'react';
import { useLocation } from 'wouter';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import HeroSection from '../components/Home/HeroSection';
import FeaturesSection from '../components/Home/FeaturesSection';
import HowItWorks from '../components/Home/HowItWorks';
import ImpactSection from '../components/Home/ImpactSection';
import { useAuth } from '../hooks/useAuth';

const HomePage = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to appropriate dashboard if already logged in
  useEffect(() => {
    if (user) {
      // Redirect based on user type after a short delay
      const timer = setTimeout(() => {
        if (user.userType === 'admin') {
          setLocation('/admin-dashboard');
        } else if (user.userType === 'official') {
          setLocation('/official-dashboard');
        } else {
          setLocation('/user-dashboard');
        }
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [user, setLocation]);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <HowItWorks />
        <ImpactSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;
