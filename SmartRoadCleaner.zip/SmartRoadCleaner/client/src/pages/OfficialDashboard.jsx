import { Switch, Route, useLocation, Redirect } from 'wouter';
import { useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import Sidebar from '../components/Layout/Sidebar';
import OfficialDashboardHome from '../components/Dashboard/OfficialDashboard/OfficialDashboardHome';
import OfficialProfile from '../components/Dashboard/OfficialDashboard/OfficialProfile';
import ViewComplaints from '../components/Dashboard/OfficialDashboard/ViewComplaints';
import UpdateStatus from '../components/Dashboard/OfficialDashboard/UpdateStatus';
import MapsPage from '../components/Dashboard/OfficialDashboard/MapsPage';
import RatingsReviews from '../components/Dashboard/OfficialDashboard/RatingsReviews';
import NotFound from './not-found';

const OfficialDashboard = () => {
  const { user, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // If user is not logged in or is not an official, redirect to home
    if (!loading && (!user || user.userType !== 'official')) {
      setLocation('/');
    }
  }, [user, loading, setLocation]);

  // Show loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="text-green-600 mb-4">
            <i className="fas fa-circle-notch fa-spin text-4xl"></i>
          </div>
          <h2 className="text-xl font-semibold text-gray-800">Loading your dashboard...</h2>
          <p className="text-gray-600 mt-2">Please wait while we prepare your experience</p>
        </div>
      </div>
    );
  }

  // If user is not an official, don't render anything (redirect effect will handle it)
  if (!user || user.userType !== 'official') {
    return null;
  }

  // Handle case where user navigates directly to /official-dashboard
  if (location === '/official-dashboard') {
    return <Redirect to="/official-dashboard/" />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <Sidebar userType="official" />
      
      <div className="flex-1 md:ml-64">
        {/* Top Navbar with official info */}
        <div className="bg-white shadow-sm">
          <div className="flex justify-between items-center py-4 px-6">
            <h2 className="text-xl font-semibold text-gray-800">
              {location === '/official-dashboard/' && 'Official Dashboard'}
              {location === '/official-dashboard/profile' && 'Official Profile'}
              {location === '/official-dashboard/complaints' && 'View Complaints'}
              {location === '/official-dashboard/update-status' && 'Update Complaint Status'}
              {location === '/official-dashboard/maps' && 'Complaint Map'}
              {location === '/official-dashboard/ratings' && 'Your Ratings & Reviews'}
              {location === '/official-dashboard/reports' && 'Reports'}
            </h2>
            <div className="flex items-center">
              <button className="text-gray-500 hover:text-gray-700 focus:outline-none mr-4">
                <i className="fas fa-bell"></i>
              </button>
              <div className="flex items-center">
                <img 
                  className="h-8 w-8 rounded-full object-cover" 
                  src={user.profilePicture || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user.fullName || user.username)}
                  alt="Official profile" 
                />
                <span className="ml-2 text-gray-700">{user.fullName || user.username}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content area */}
        <div className="flex-1 overflow-auto">
          <Switch>
            <Route path="/official-dashboard/" component={OfficialDashboardHome} />
            <Route path="/official-dashboard/profile" component={OfficialProfile} />
            <Route path="/official-dashboard/complaints" component={ViewComplaints} />
            <Route path="/official-dashboard/update-status" component={UpdateStatus} />
            <Route path="/official-dashboard/maps" component={MapsPage} />
            <Route path="/official-dashboard/ratings" component={RatingsReviews} />
            <Route path="/official-dashboard/reports" component={ReportsPage} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    </div>
  );
};

// Placeholder Reports component
const ReportsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Performance Reports</h2>
      <div className="mb-6">
        <p className="text-gray-600">
          View your performance metrics and complaint resolution statistics.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-lg mb-3">Resolution Time (Average)</h3>
          <div className="flex items-center">
            <div className="w-16 h-16 rounded-full bg-green-600 text-white flex items-center justify-center text-xl font-bold">
              2.4d
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Average time to resolve a complaint</p>
              <p className="text-green-600 text-sm mt-1">
                <i className="fas fa-arrow-down mr-1"></i> 
                15% faster than last month
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-lg mb-3">Complaint Resolution Rate</h3>
          <div className="flex items-center">
            <div className="w-16 h-16 rounded-full bg-green-600 text-white flex items-center justify-center text-xl font-bold">
              92%
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Successfully resolved complaints</p>
              <p className="text-green-600 text-sm mt-1">
                <i className="fas fa-arrow-up mr-1"></i> 
                5% improvement from previous quarter
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-medium text-gray-800 mb-4">Monthly Progress</h3>
      <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-chart-line text-green-600 text-3xl mb-2"></i>
          <p className="text-gray-600">Monthly performance chart would appear here</p>
        </div>
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border rounded-lg p-4">
          <h4 className="font-medium mb-2">Complaints Assigned</h4>
          <p className="text-3xl font-bold text-gray-800">127</p>
          <p className="text-sm text-gray-500">Last 30 days</p>
        </div>
        
        <div className="border rounded-lg p-4">
          <h4 className="font-medium mb-2">Resolved</h4>
          <p className="text-3xl font-bold text-green-600">118</p>
          <p className="text-sm text-gray-500">Last 30 days</p>
        </div>
        
        <div className="border rounded-lg p-4">
          <h4 className="font-medium mb-2">Average Rating</h4>
          <p className="text-3xl font-bold text-gray-800">4.8</p>
          <div className="flex text-yellow-400 text-sm">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star-half-alt"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default OfficialDashboard;
