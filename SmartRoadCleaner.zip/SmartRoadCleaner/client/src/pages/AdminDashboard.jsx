import { Switch, Route, useLocation, Redirect } from 'wouter';
import { useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import Sidebar from '../components/Layout/Sidebar';
import AdminDashboardHome from '../components/Dashboard/AdminDashboard/AdminDashboardHome';
import NotFound from './not-found';

const AdminDashboard = () => {
  const { user, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // If user is not logged in or is not an admin, redirect to home
    if (!loading && (!user || user.userType !== 'admin')) {
      setLocation('/');
    }
  }, [user, loading, setLocation]);

  // Show loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="text-green-600 mb-4">
            <i className="fas fa-circle-notch fa-spin text-4xl"></i>
          </div>
          <h2 className="text-xl font-semibold text-gray-800">Loading your dashboard...</h2>
          <p className="text-gray-600 mt-2">Please wait while we prepare your experience</p>
        </div>
      </div>
    );
  }

  // If user is not an admin, don't render anything (redirect effect will handle it)
  if (!user || user.userType !== 'admin') {
    return null;
  }

  // Handle case where user navigates directly to /admin-dashboard
  if (location === '/admin-dashboard') {
    return <Redirect to="/admin-dashboard/" />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <Sidebar userType="admin" />
      
      <div className="flex-1 md:ml-64">
        {/* Top Navbar with admin info */}
        <div className="bg-white shadow-sm">
          <div className="flex justify-between items-center py-4 px-6">
            <h2 className="text-xl font-semibold text-gray-800">
              {location === '/admin-dashboard/' && 'Admin Dashboard'}
              {location === '/admin-dashboard/users' && 'Manage Users'}
              {location === '/admin-dashboard/officials' && 'Manage Officials'}
              {location === '/admin-dashboard/complaints' && 'All Complaints'}
              {location === '/admin-dashboard/hot-zones' && 'Hot Zones'}
              {location === '/admin-dashboard/analytics' && 'Analytics'}
              {location === '/admin-dashboard/reports' && 'Reports'}
            </h2>
            <div className="flex items-center">
              <button className="text-gray-500 hover:text-gray-700 focus:outline-none mr-4">
                <i className="fas fa-bell"></i>
              </button>
              <div className="flex items-center">
                <img 
                  className="h-8 w-8 rounded-full object-cover" 
                  src={user.profilePicture || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user.fullName || user.username)}
                  alt="Admin profile" 
                />
                <span className="ml-2 text-gray-700">{user.fullName || user.username}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content area */}
        <div className="flex-1 overflow-auto">
          <Switch>
            <Route path="/admin-dashboard/" component={AdminDashboardHome} />
            <Route path="/admin-dashboard/users" component={ManageUsersPage} />
            <Route path="/admin-dashboard/officials" component={ManageOfficialsPage} />
            <Route path="/admin-dashboard/complaints" component={AllComplaintsPage} />
            <Route path="/admin-dashboard/hot-zones" component={HotZonesPage} />
            <Route path="/admin-dashboard/analytics" component={AnalyticsPage} />
            <Route path="/admin-dashboard/reports" component={ReportsPage} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    </div>
  );
};

// Placeholder components for admin dashboard pages
const ManageUsersPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Manage Users</h2>
      <p className="text-gray-600 mb-4">Manage all citizen users registered in the system.</p>
      
      <div className="mb-4 flex justify-between items-center">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search users..." 
            className="pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
          />
          <div className="absolute left-3 top-2.5 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
        
        <button className="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors">
          <i className="fas fa-plus mr-2"></i>
          Add User
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Complaints</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">John Doe</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">john.doe@example.com</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">+1 234 567 8900</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">12</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">85</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-3">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Jane Smith</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">jane.smith@example.com</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">+1 234 567 8901</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">8</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">63</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-3">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-500">
          Showing 2 of 24 users
        </div>
        <div className="flex">
          <button className="py-1 px-3 border rounded-l-md bg-gray-50">Previous</button>
          <button className="py-1 px-3 border-t border-b border-r bg-green-600 text-white">1</button>
          <button className="py-1 px-3 border-t border-b border-r bg-gray-50">2</button>
          <button className="py-1 px-3 border-t border-b border-r bg-gray-50">3</button>
          <button className="py-1 px-3 border rounded-r-md bg-gray-50">Next</button>
        </div>
      </div>
    </div>
  </div>
);

const ManageOfficialsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Manage Officials</h2>
      <p className="text-gray-600 mb-4">Manage all municipal officials registered in the system.</p>
      
      <div className="mb-4 flex justify-between items-center">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search officials..." 
            className="pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
          />
          <div className="absolute left-3 top-2.5 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
        
        <button className="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors">
          <i className="fas fa-plus mr-2"></i>
          Add Official
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Official</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resolved</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Robert Johnson</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">robert.j@municipality.gov</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">+1 234 567 8902</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">87</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex text-yellow-400 text-sm">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star-half-alt"></i>
                  <span className="ml-1 text-gray-600">4.7</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-3">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Sarah Williams</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">sarah.w@municipality.gov</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">+1 234 567 8903</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">65</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex text-yellow-400 text-sm">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <span className="ml-1 text-gray-600">4.2</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-3">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-500">
          Showing 2 of 12 officials
        </div>
        <div className="flex">
          <button className="py-1 px-3 border rounded-l-md bg-gray-50">Previous</button>
          <button className="py-1 px-3 border-t border-b border-r bg-green-600 text-white">1</button>
          <button className="py-1 px-3 border-t border-b border-r bg-gray-50">2</button>
          <button className="py-1 px-3 border rounded-r-md bg-gray-50">Next</button>
        </div>
      </div>
    </div>
  </div>
);

const AllComplaintsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">All Complaints</h2>
      <p className="text-gray-600 mb-4">View and manage all complaints in the system.</p>
      
      <div className="mb-4 flex flex-col md:flex-row md:justify-between md:items-center space-y-3 md:space-y-0">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search complaints..." 
            className="pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
          />
          <div className="absolute left-3 top-2.5 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <select className="border rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-green-500">
            <option>All Statuses</option>
            <option>Pending</option>
            <option>In Progress</option>
            <option>Resolved</option>
          </select>
          
          <select className="border rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-green-500">
            <option>Date: Newest</option>
            <option>Date: Oldest</option>
          </select>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Complaint</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reported By</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned To</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">#C-2305</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-md bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Garbage pile on roadside</div>
                    <div className="text-xs text-gray-500">May 23, 2023</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Commercial Street, Sector 9</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">John Doe</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Robert Johnson</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                  Pending
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-2">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-blue-600 hover:text-blue-800 mr-2">
                  <i className="fas fa-eye"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">#C-2304</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-md bg-gray-200"></div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Broken street light</div>
                    <div className="text-xs text-gray-500">May 22, 2023</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Residential Area, Sector 12</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Jane Smith</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Sarah Williams</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                  In Progress
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800 mr-2">
                  <i className="fas fa-edit"></i>
                </button>
                <button className="text-blue-600 hover:text-blue-800 mr-2">
                  <i className="fas fa-eye"></i>
                </button>
                <button className="text-red-600 hover:text-red-800">
                  <i className="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-500">
          Showing 2 of 132 complaints
        </div>
        <div className="flex">
          <button className="py-1 px-3 border rounded-l-md bg-gray-50">Previous</button>
          <button className="py-1 px-3 border-t border-b border-r bg-green-600 text-white">1</button>
          <button className="py-1 px-3 border-t border-b border-r bg-gray-50">2</button>
          <button className="py-1 px-3 border-t border-b border-r bg-gray-50">3</button>
          <button className="py-1 px-3 border rounded-r-md bg-gray-50">Next</button>
        </div>
      </div>
    </div>
  </div>
);

const HotZonesPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Complaint Hot Zones</h2>
      <p className="text-gray-600 mb-4">View areas with high density of complaints to prioritize action.</p>
      
      <div className="h-[500px] bg-gray-100 rounded-lg mb-6">
        <div className="h-full w-full rounded-lg flex items-center justify-center">
          <div className="text-center">
            <i className="fas fa-map-marked-alt text-green-600 text-4xl mb-3"></i>
            <p className="text-gray-600">Interactive complaint density map would appear here</p>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-medium text-gray-800 mb-4">Priority Zones</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-red-50 rounded-md p-4">
          <div className="text-xs text-red-500 uppercase font-semibold">High Priority Zone</div>
          <div className="text-lg font-medium mt-1">Sector 7</div>
          <div className="text-sm text-gray-600">23 open complaints</div>
          <div className="mt-2">
            <button className="text-red-600 text-sm font-medium">View Details</button>
          </div>
        </div>
        
        <div className="bg-yellow-50 rounded-md p-4">
          <div className="text-xs text-yellow-500 uppercase font-semibold">Medium Priority</div>
          <div className="text-lg font-medium mt-1">Downtown</div>
          <div className="text-sm text-gray-600">17 open complaints</div>
          <div className="mt-2">
            <button className="text-yellow-600 text-sm font-medium">View Details</button>
          </div>
        </div>
        
        <div className="bg-green-50 rounded-md p-4">
          <div className="text-xs text-green-500 uppercase font-semibold">Low Priority</div>
          <div className="text-lg font-medium mt-1">West Hills</div>
          <div className="text-sm text-gray-600">8 open complaints</div>
          <div className="mt-2">
            <button className="text-green-600 text-sm font-medium">View Details</button>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-medium text-gray-800 mb-4">Hot Zone Analysis</h3>
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="text-sm text-gray-600">
          <p className="mb-2">
            <strong>AI-based analysis:</strong> The system has detected a pattern of increasing complaints in Sector 7 over the last 2 weeks. 
            Most of the complaints are related to garbage collection issues.
          </p>
          <p className="mb-2">
            <strong>Recommended action:</strong> Allocate additional cleaning resources to Sector 7 to address the backlog and prevent further deterioration.
          </p>
          <p>
            <strong>Expected outcome:</strong> With proper resource allocation, the complaint volume in this area should decrease by approximately 60% within 7 days.
          </p>
        </div>
      </div>
    </div>
  </div>
);

const AnalyticsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">System Analytics</h2>
      <p className="text-gray-600 mb-4">Comprehensive statistics and insights about system usage and performance.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="text-sm text-gray-500 uppercase font-medium">Total Users</div>
          <div className="flex items-center mt-2">
            <div className="text-3xl font-bold">458</div>
            <div className="ml-2 text-green-500 text-sm">
              <i className="fas fa-arrow-up mr-1"></i>12%
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-1">vs last month</div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="text-sm text-gray-500 uppercase font-medium">Total Complaints</div>
          <div className="flex items-center mt-2">
            <div className="text-3xl font-bold">1,287</div>
            <div className="ml-2 text-green-500 text-sm">
              <i className="fas fa-arrow-up mr-1"></i>8%
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-1">vs last month</div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="text-sm text-gray-500 uppercase font-medium">Resolution Rate</div>
          <div className="flex items-center mt-2">
            <div className="text-3xl font-bold">85%</div>
            <div className="ml-2 text-green-500 text-sm">
              <i className="fas fa-arrow-up mr-1"></i>3%
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-1">vs last month</div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="text-sm text-gray-500 uppercase font-medium">Avg. Resolution Time</div>
          <div className="flex items-center mt-2">
            <div className="text-3xl font-bold">2.6d</div>
            <div className="ml-2 text-green-500 text-sm">
              <i className="fas fa-arrow-down mr-1"></i>10%
            </div>
          </div>
          <div className="text-xs text-gray-500 mt-1">vs last month</div>
        </div>
      </div>
      
      <h3 className="text-xl font-medium text-gray-800 mb-4">Complaint Trends</h3>
      <div className="h-64 bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-chart-line text-green-600 text-3xl mb-2"></i>
          <p className="text-gray-600">Complaint trend chart would appear here</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-xl font-medium text-gray-800 mb-4">Complaint Types</h3>
          <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <i className="fas fa-chart-pie text-green-600 text-3xl mb-2"></i>
              <p className="text-gray-600">Complaint type distribution chart</p>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-xl font-medium text-gray-800 mb-4">User Activity</h3>
          <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <i className="fas fa-chart-bar text-green-600 text-3xl mb-2"></i>
              <p className="text-gray-600">User activity chart would appear here</p>
            </div>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-medium text-gray-800 mb-4">AI Insights</h3>
      <div className="bg-gray-50 p-4 rounded-lg">
        <ul className="space-y-2 text-sm text-gray-600">
          <li className="flex items-start">
            <i className="fas fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
            <span>Garbage-related complaints have increased by 15% in the northern districts over the past month.</span>
          </li>
          <li className="flex items-start">
            <i className="fas fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
            <span>Officials assigned to the eastern zone have a 12% higher resolution rate than the average.</span>
          </li>
          <li className="flex items-start">
            <i className="fas fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
            <span>The system predicts a 20% increase in complaints related to drainage during the upcoming monsoon season.</span>
          </li>
          <li className="flex items-start">
            <i className="fas fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
            <span>User engagement has increased by 23% since implementing the rewards system.</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
);

const ReportsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">System Reports</h2>
      <p className="text-gray-600 mb-4">Generate and download reports for various system metrics.</p>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-800 mb-3">Available Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-2">
              <i className="fas fa-file-alt text-green-600 text-xl mr-2"></i>
              <h4 className="font-medium">User Activity Report</h4>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Detailed analytics on user registrations, logins, and contributions.
            </p>
            <div className="flex justify-between items-center">
              <div className="text-xs text-gray-500">
                <i className="far fa-clock mr-1"></i> Last generated: 2 days ago
              </div>
              <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                Generate
              </button>
            </div>
          </div>
          
          <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-2">
              <i className="fas fa-file-alt text-green-600 text-xl mr-2"></i>
              <h4 className="font-medium">Complaint Analytics</h4>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Statistics on complaint volume, categories, resolution times, and ratings.
            </p>
            <div className="flex justify-between items-center">
              <div className="text-xs text-gray-500">
                <i className="far fa-clock mr-1"></i> Last generated: 1 day ago
              </div>
              <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                Generate
              </button>
            </div>
          </div>
          
          <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-2">
              <i className="fas fa-file-alt text-green-600 text-xl mr-2"></i>
              <h4 className="font-medium">Official Performance</h4>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Performance metrics for each official, including resolution rates and ratings.
            </p>
            <div className="flex justify-between items-center">
              <div className="text-xs text-gray-500">
                <i className="far fa-clock mr-1"></i> Last generated: 3 days ago
              </div>
              <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                Generate
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-800 mb-3">Custom Report</h3>
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Report Type</label>
              <select className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-green-500">
                <option>User Activity</option>
                <option>Complaint Analytics</option>
                <option>Official Performance</option>
                <option>System Health</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <select className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-green-500">
                <option>Last 7 days</option>
                <option>Last 30 days</option>
                <option>Last 90 days</option>
                <option>Custom range</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Format</label>
              <select className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-green-500">
                <option>PDF</option>
                <option>Excel</option>
                <option>CSV</option>
              </select>
            </div>
          </div>
          
          <button className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors">
            Generate Custom Report
          </button>
        </div>
      </div>
      
      <h3 className="text-lg font-medium text-gray-800 mb-3">Recent Reports</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Report Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Generated</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Format</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">User Activity Report</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">May 25, 2023</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">PDF</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">1.2 MB</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800">
                  <i className="fas fa-download"></i>
                </button>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">Complaint Analytics</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">May 24, 2023</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">Excel</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">2.4 MB</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800">
                  <i className="fas fa-download"></i>
                </button>
              </td>
            </tr>
            <tr>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">Official Performance</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">May 22, 2023</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">PDF</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-500">1.8 MB</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button className="text-green-600 hover:text-green-800">
                  <i className="fas fa-download"></i>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

export default AdminDashboard;
