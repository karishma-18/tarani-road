import { Switch, Route, useLocation, Redirect } from 'wouter';
import { useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import Sidebar from '../components/Layout/Sidebar';
import UserDashboardHome from '../components/Dashboard/UserDashboard/UserDashboardHome';
import ProfilePage from '../components/Dashboard/UserDashboard/ProfilePage';
import ComplaintForm from '../components/Dashboard/UserDashboard/ComplaintForm';
import TrackComplaints from '../components/Dashboard/UserDashboard/TrackComplaints';
import RewardsPage from '../components/Dashboard/UserDashboard/RewardsPage';
import CollaboratePage from '../components/Dashboard/UserDashboard/CollaboratePage';
import PublicRating from '../components/Dashboard/UserDashboard/PublicRating';
import AboutPage from '../components/Dashboard/UserDashboard/AboutPage';
import NotFound from './not-found';

const UserDashboard = () => {
  const { user, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // If user is not logged in or is not a user, redirect to home
    if (!loading && (!user || user.userType !== 'user')) {
      setLocation('/');
    }
  }, [user, loading, setLocation]);

  // Show loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="text-green-600 mb-4">
            <i className="fas fa-circle-notch fa-spin text-4xl"></i>
          </div>
          <h2 className="text-xl font-semibold text-gray-800">Loading your dashboard...</h2>
          <p className="text-gray-600 mt-2">Please wait while we prepare your experience</p>
        </div>
      </div>
    );
  }

  // If user is not a user, don't render anything (redirect effect will handle it)
  if (!user || user.userType !== 'user') {
    return null;
  }

  // Handle case where user navigates directly to /user-dashboard
  if (location === '/user-dashboard') {
    return <Redirect to="/user-dashboard/" />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <Sidebar userType="user" />
      
      <div className="flex-1 md:ml-64">
        {/* Top Navbar with user info */}
        <div className="bg-white shadow-sm">
          <div className="flex justify-between items-center py-4 px-6">
            <h2 className="text-xl font-semibold text-gray-800">
              {location === '/user-dashboard/' && 'Dashboard'}
              {location === '/user-dashboard/profile' && 'Your Profile'}
              {location === '/user-dashboard/about' && 'About Us'}
              {location === '/user-dashboard/new-complaint' && 'Submit New Complaint'}
              {location === '/user-dashboard/track' && 'Track Complaints'}
              {location === '/user-dashboard/collaborate' && 'Collaborate'}
              {location === '/user-dashboard/rewards' && 'Rewards & Leaderboard'}
              {location === '/user-dashboard/ratings' && 'Public Ratings'}
            </h2>
            <div className="flex items-center">
              <button className="text-gray-500 hover:text-gray-700 focus:outline-none mr-4">
                <i className="fas fa-bell"></i>
              </button>
              <div className="flex items-center">
                <img 
                  className="h-8 w-8 rounded-full object-cover" 
                  src={user.profilePicture || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user.fullName || user.username)}
                  alt="User profile" 
                />
                <span className="ml-2 text-gray-700">{user.fullName || user.username}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content area */}
        <div className="flex-1 overflow-auto">
          <Switch>
            <Route path="/user-dashboard/" component={UserDashboardHome} />
            <Route path="/user-dashboard/profile" component={ProfilePage} />
            <Route path="/user-dashboard/about" component={AboutPage} />
            <Route path="/user-dashboard/new-complaint" component={ComplaintForm} />
            <Route path="/user-dashboard/track" component={TrackComplaints} />
            <Route path="/user-dashboard/collaborate" component={CollaboratePage} />
            <Route path="/user-dashboard/rewards" component={RewardsPage} />
            <Route path="/user-dashboard/ratings" component={PublicRating} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    </div>
  );
};

// Placeholder for AboutPage component
const AboutPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">About Smart Road Cleanliness Tracker</h2>
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/2 pr-4">
          <p className="text-gray-600 mb-4">
            Smart Road Cleanliness Tracker is an innovative platform designed to connect citizens with municipal authorities
            to ensure cleaner roads and a greener environment.
          </p>
          <p className="text-gray-600 mb-4">
            Our mission is to empower citizens to take an active role in maintaining their community's cleanliness
            while providing municipal authorities with real-time data to improve their services.
          </p>
          <p className="text-gray-600 mb-4">
            Through citizen reporting, collaborative cleanup events, and a rewards system, we're building
            a cleaner, more sustainable future together.
          </p>
        </div>
        <div className="md:w-1/2 mt-4 md:mt-0">
          <img 
            src="https://images.unsplash.com/photo-1598886221321-91c441ac1927?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" 
            alt="Clean city" 
            className="rounded-lg w-full h-64 object-cover"
          />
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-gray-800 mt-8 mb-3">How We Help</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <div className="text-green-600 text-2xl mb-2">
            <i className="fas fa-map-marked-alt"></i>
          </div>
          <h4 className="font-medium text-gray-800 mb-2">Identifying Problem Areas</h4>
          <p className="text-gray-600 text-sm">
            We help municipal authorities identify cleanliness hotspots that require immediate attention.
          </p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <div className="text-green-600 text-2xl mb-2">
            <i className="fas fa-users"></i>
          </div>
          <h4 className="font-medium text-gray-800 mb-2">Community Engagement</h4>
          <p className="text-gray-600 text-sm">
            We encourage citizens to volunteer and participate in cleanup drives to keep their communities clean.
          </p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <div className="text-green-600 text-2xl mb-2">
            <i className="fas fa-award"></i>
          </div>
          <h4 className="font-medium text-gray-800 mb-2">Recognition System</h4>
          <p className="text-gray-600 text-sm">
            We recognize and reward citizens and officials who contribute to making our city cleaner.
          </p>
        </div>
      </div>
    </div>
  </div>
);

export default UserDashboard;
