import { useState, useEffect } from 'react';

export const useMaps = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    // Check if Google Maps is already loaded
    if (window.google && window.google.maps) {
      setIsLoaded(true);
      return;
    }

    // Load Google Maps API
    const initMap = () => {
      setIsLoaded(true);
    };

    const handleError = (error) => {
      setLoadError(error);
    };

    // Get API key from environment variables
    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyC9y5aWqmkPSXNGEEXXxkzQAZRR9vspf2c';

    // Create script element for Google Maps
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    script.async = true;
    script.defer = true;
    script.addEventListener('load', initMap);
    script.addEventListener('error', handleError);

    // Add script to document
    document.head.appendChild(script);

    // Cleanup function
    return () => {
      script.removeEventListener('load', initMap);
      script.removeEventListener('error', handleError);
    };
  }, []);

  // Custom geocoding function
  const geocodeAddress = async (address) => {
    if (!isLoaded || loadError) {
      throw new Error('Google Maps not available');
    }

    return new Promise((resolve, reject) => {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ address }, (results, status) => {
        if (status === 'OK' && results[0]) {
          const { lat, lng } = results[0].geometry.location;
          resolve({
            lat: lat(),
            lng: lng(),
            formattedAddress: results[0].formatted_address
          });
        } else {
          reject(new Error(`Geocoding failed: ${status}`));
        }
      });
    });
  };

  // Get address from coordinates
  const reverseGeocode = async (lat, lng) => {
    if (!isLoaded || loadError) {
      throw new Error('Google Maps not available');
    }

    return new Promise((resolve, reject) => {
      const geocoder = new window.google.maps.Geocoder();
      const latlng = { lat, lng };

      geocoder.geocode({ location: latlng }, (results, status) => {
        if (status === 'OK' && results[0]) {
          resolve(results[0].formatted_address);
        } else {
          reject(new Error(`Reverse geocoding failed: ${status}`));
        }
      });
    });
  };

  return { isLoaded, loadError, geocodeAddress, reverseGeocode };
};
