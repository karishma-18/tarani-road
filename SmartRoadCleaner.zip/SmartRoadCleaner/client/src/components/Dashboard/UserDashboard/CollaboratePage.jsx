import { useState } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { useComplaint } from '../../../hooks/useComplaint';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../../lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useMaps } from '../../../hooks/useMaps';
import GoogleMapComponent from '../../Maps/GoogleMapComponent';

const EventCard = ({ event, userEvents, onJoin }) => {
  const { user } = useAuth();
  
  // Check if user is already part of this event
  const isJoined = userEvents.some(e => e.id === event.id);
  // Check if user is the creator
  const isCreator = event.createdBy === user?.id;
  // Check if event is full
  const isFull = false; // In a real app, this would be calculated based on members count and capacity
  
  // Format date
  const eventDate = new Date(event.date);
  const formattedDate = eventDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const formattedTime = eventDate.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  // Check if event is in the past
  const isPast = eventDate < new Date();
  
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white rounded-lg shadow-sm overflow-hidden"
    >
      <div className="h-40 bg-gray-200 relative">
        <img
          src="https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
          alt="Cleanup event"
          className="w-full h-full object-cover"
        />
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black to-transparent opacity-50"></div>
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h3 className="text-lg font-bold">{event.title}</h3>
        </div>
      </div>
      
      <div className="p-4">
        <p className="text-gray-600 text-sm mb-3">{event.description}</p>
        
        <div className="flex items-center text-sm text-gray-600 mb-2">
          <i className="fas fa-map-marker-alt text-green-600 mr-2"></i>
          <span>{event.location}</span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600 mb-2">
          <i className="far fa-calendar-alt text-green-600 mr-2"></i>
          <span>{formattedDate} at {formattedTime}</span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600 mb-4">
          <i className="fas fa-users text-green-600 mr-2"></i>
          <span>Capacity: {event.capacity} volunteers</span>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="text-xs text-gray-500">
            {isCreator ? (
              <span className="text-green-600">You're the organizer</span>
            ) : isJoined ? (
              <span className="text-blue-600">You're participating</span>
            ) : null}
          </div>
          
          <button
            onClick={() => onJoin(event)}
            disabled={isJoined || isCreator || isFull || isPast}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              isJoined
                ? 'bg-gray-100 text-gray-600 cursor-default'
                : isCreator
                  ? 'bg-gray-100 text-gray-600 cursor-default'
                  : isFull
                    ? 'bg-gray-100 text-gray-600 cursor-not-allowed'
                    : isPast
                      ? 'bg-gray-100 text-gray-600 cursor-not-allowed'
                      : 'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            {isJoined
              ? 'Joined'
              : isCreator
                ? 'Organizer'
                : isFull
                  ? 'Full'
                  : isPast
                    ? 'Past Event'
                    : 'Join Event'}
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const CreateEventModal = ({ isOpen, onClose, onSubmit }) => {
  const { user } = useAuth();
  const { geocodeAddress } = useMaps();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    date: '',
    time: '',
    capacity: 10,
    latitude: '',
    longitude: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [addressInput, setAddressInput] = useState('');
  const [mapLocation, setMapLocation] = useState(null);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAddressSearch = async (e) => {
    e.preventDefault();
    
    if (!addressInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter an address to search",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const result = await geocodeAddress(addressInput);
      
      setMapLocation({
        lat: result.lat,
        lng: result.lng
      });
      
      setFormData(prev => ({
        ...prev,
        location: result.formattedAddress,
        latitude: result.lat.toString(),
        longitude: result.lng.toString()
      }));
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to find the location. Please try a different address.",
        variant: "destructive"
      });
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.title || !formData.description || !formData.location || !formData.date || !formData.time || !formData.capacity) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Combine date and time
      const dateTime = new Date(`${formData.date}T${formData.time}`);
      
      const eventData = {
        title: formData.title,
        description: formData.description,
        location: formData.location,
        date: dateTime.toISOString(),
        capacity: parseInt(formData.capacity),
        createdBy: user.id
      };
      
      await onSubmit(eventData);
      
      // Reset form and close modal
      setFormData({
        title: '',
        description: '',
        location: '',
        date: '',
        time: '',
        capacity: 10,
        latitude: '',
        longitude: ''
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to create event",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 text-center">
        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="inline-block w-full max-w-2xl bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all"
        >
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Create Cleanup Event</h3>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Event Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="e.g., Beach Cleanup Drive"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows="4"
                  placeholder="Describe the cleanup event and what volunteers should bring..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  required
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Location <span className="text-red-500">*</span>
                </label>
                <div className="flex mb-2">
                  <input
                    type="text"
                    value={addressInput}
                    onChange={(e) => setAddressInput(e.target.value)}
                    placeholder="Enter event location address"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddressSearch}
                    className="px-4 py-2 bg-green-600 text-white rounded-r-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  >
                    <i className="fas fa-search"></i>
                  </button>
                </div>
                
                {mapLocation && (
                  <div className="h-[200px] bg-gray-100 rounded-md overflow-hidden mb-2">
                    <GoogleMapComponent
                      center={mapLocation}
                      markers={[{ ...mapLocation, status: 'pending' }]}
                      defaultZoom={15}
                      height="200px"
                    />
                  </div>
                )}
                
                <input
                  type="hidden"
                  name="location"
                  value={formData.location}
                />
                <input
                  type="hidden"
                  name="latitude"
                  value={formData.latitude}
                />
                <input
                  type="hidden"
                  name="longitude"
                  value={formData.longitude}
                />
                
                {formData.location && (
                  <div className="text-sm text-gray-600">
                    <i className="fas fa-map-marker-alt text-green-600 mr-1"></i>
                    {formData.location}
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    min={new Date().toISOString().split('T')[0]} // Prevent past dates
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
                    Time <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="time"
                    id="time"
                    name="time"
                    value={formData.time}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="capacity" className="block text-sm font-medium text-gray-700 mb-1">
                  Volunteer Capacity <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  id="capacity"
                  name="capacity"
                  value={formData.capacity}
                  onChange={handleInputChange}
                  min="1"
                  max="100"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  required
                />
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Creating...
                  </>
                ) : "Create Event"}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

const CollaboratePage = () => {
  const { user } = useAuth();
  const { createCollaboration, joinCollaboration } = useComplaint();
  const { toast } = useToast();
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [filter, setFilter] = useState('upcoming'); // 'upcoming', 'past', 'joined', 'created'
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'map'
  
  // Fetch all collaborations
  const { data: collaborations = [], isLoading: collaborationsLoading, refetch } = useQuery({
    queryKey: ['/api/collaborations'],
    queryFn: () => apiRequest('GET', '/api/collaborations').then(res => res.json())
  });
  
  // Fetch collaboration members to check which events the user has joined
  const { data: members = [], isLoading: membersLoading } = useQuery({
    queryKey: ['/api/collaboration-members', { userId: user?.id }],
    queryFn: () => apiRequest('GET', `/api/collaboration-members?userId=${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });
  
  // Filter collaborations based on current filter
  const filteredCollaborations = collaborations.filter(collab => {
    const collabDate = new Date(collab.date);
    const now = new Date();
    
    if (filter === 'upcoming') {
      return collabDate >= now;
    } else if (filter === 'past') {
      return collabDate < now;
    } else if (filter === 'joined') {
      return members.some(member => member.collaborationId === collab.id);
    } else if (filter === 'created') {
      return collab.createdBy === user?.id;
    }
    return true;
  });
  
  // Get events user has joined
  const userEvents = collaborations.filter(collab => 
    members.some(member => member.collaborationId === collab.id)
  );
  
  // Prepare markers for map view
  const mapMarkers = filteredCollaborations.map(collab => ({
    lat: parseFloat(collab.latitude || 0),
    lng: parseFloat(collab.longitude || 0),
    status: new Date(collab.date) >= new Date() ? 'pending' : 'resolved',
    title: collab.title,
    info: `
      <div class="p-2">
        <h3 class="font-medium">${collab.title}</h3>
        <p class="text-sm text-gray-600">${collab.location}</p>
        <p class="text-xs text-gray-500 mt-1">Date: ${new Date(collab.date).toLocaleDateString()}</p>
      </div>
    `
  }));
  
  const handleCreateEvent = async (eventData) => {
    try {
      await createCollaboration(eventData);
      refetch();
      toast({
        title: "Success",
        description: "Cleanup event created successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to create event",
        variant: "destructive"
      });
      throw error;
    }
  };
  
  const handleJoinEvent = async (event) => {
    try {
      await joinCollaboration(event.id, user.id);
      refetch();
      toast({
        title: "Success",
        description: "You have joined the cleanup event"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to join event",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="p-6">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Community Cleanup Events</h2>
          <p className="text-gray-600">Join forces with other citizens to make our city cleaner</p>
        </div>
        
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors flex items-center"
        >
          <i className="fas fa-plus mr-2"></i>
          Create Event
        </button>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm mb-6">
        <div className="p-4 flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilter('upcoming')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                filter === 'upcoming' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-calendar-alt mr-2"></i>
              Upcoming Events
            </button>
            <button
              onClick={() => setFilter('joined')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                filter === 'joined' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-check-circle mr-2"></i>
              Events You Joined
            </button>
            <button
              onClick={() => setFilter('created')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                filter === 'created' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-user-edit mr-2"></i>
              Your Events
            </button>
            <button
              onClick={() => setFilter('past')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                filter === 'past' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-history mr-2"></i>
              Past Events
            </button>
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`w-10 h-10 flex items-center justify-center rounded-md ${
                viewMode === 'grid'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-th"></i>
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`w-10 h-10 flex items-center justify-center rounded-md ${
                viewMode === 'map'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-map-marked-alt"></i>
            </button>
          </div>
        </div>
      </div>
      
      {collaborationsLoading || membersLoading ? (
        <div className="flex items-center justify-center min-h-[300px]">
          <div className="text-center">
            <i className="fas fa-circle-notch fa-spin text-green-600 text-3xl mb-3"></i>
            <p className="text-gray-600">Loading events...</p>
          </div>
        </div>
      ) : filteredCollaborations.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <i className="fas fa-calendar-times text-gray-400 text-4xl mb-3"></i>
          <h3 className="text-xl font-medium text-gray-900 mb-2">No events found</h3>
          <p className="text-gray-600 mb-4">
            {filter === 'upcoming'
              ? "There are no upcoming cleanup events scheduled."
              : filter === 'joined'
                ? "You haven't joined any cleanup events yet."
                : filter === 'created'
                  ? "You haven't created any cleanup events yet."
                  : "There are no past cleanup events to display."}
          </p>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            <i className="fas fa-plus mr-2"></i>
            Create New Event
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCollaborations.map(event => (
            <EventCard
              key={event.id}
              event={event}
              userEvents={userEvents}
              onJoin={handleJoinEvent}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="h-[70vh] w-full">
            <GoogleMapComponent
              markers={mapMarkers}
              defaultZoom={12}
              height="100%"
            />
          </div>
          <div className="p-4 bg-gray-50 flex items-center justify-center space-x-6">
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Upcoming Events</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-gray-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Past Events</span>
            </div>
          </div>
        </div>
      )}
      
      <CreateEventModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreateEvent}
      />
      
      <div className="bg-green-50 rounded-lg p-4 mt-8">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="fas fa-lightbulb text-green-600 text-xl"></i>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-800">Why join a cleanup event?</h3>
            <div className="mt-2 text-sm text-green-700">
              <ul className="list-disc pl-5 space-y-1">
                <li>Make a tangible difference in your community</li>
                <li>Meet like-minded citizens who care about cleanliness</li>
                <li>Earn additional points and recognition on the leaderboard</li>
                <li>Gain valuable experience in environmental conservation</li>
                <li>Receive a certificate of participation for each event</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaboratePage;
