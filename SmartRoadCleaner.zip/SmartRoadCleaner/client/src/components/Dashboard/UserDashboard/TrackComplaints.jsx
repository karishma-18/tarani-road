import { useState, useEffect } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { useComplaint } from '../../../hooks/useComplaint';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../../lib/queryClient';
import GoogleMapComponent from '../../Maps/GoogleMapComponent';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

const ComplaintStatusBadge = ({ status }) => {
  let bgColor, textColor, label;
  
  switch (status) {
    case 'pending':
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-800';
      label = 'Pending';
      break;
    case 'in-progress':
      bgColor = 'bg-blue-100';
      textColor = 'text-blue-800';
      label = 'In Progress';
      break;
    case 'resolved':
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
      label = 'Resolved';
      break;
    default:
      bgColor = 'bg-gray-100';
      textColor = 'text-gray-800';
      label = status.charAt(0).toUpperCase() + status.slice(1);
  }
  
  return (
    <span className={`px-2 py-1 text-xs rounded-full ${bgColor} ${textColor}`}>
      {label}
    </span>
  );
};

const ComplaintCard = ({ complaint, onRate }) => {
  const formattedDate = new Date(complaint.createdAt).toLocaleDateString();
  const resolvedDate = complaint.completedAt ? new Date(complaint.completedAt).toLocaleDateString() : null;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
    >
      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-medium text-gray-900">{complaint.title}</h3>
          <ComplaintStatusBadge status={complaint.status} />
        </div>
        
        <p className="mt-2 text-sm text-gray-600">{complaint.description}</p>
        
        <div className="mt-3 flex items-center text-xs text-gray-500">
          <i className="fas fa-map-marker-alt mr-1"></i>
          <span>{complaint.location}</span>
        </div>
        
        <div className="mt-1 flex items-center text-xs text-gray-500">
          <i className="far fa-calendar-alt mr-1"></i>
          <span>Reported: {formattedDate}</span>
        </div>
        
        {resolvedDate && (
          <div className="mt-1 flex items-center text-xs text-green-600">
            <i className="fas fa-check-circle mr-1"></i>
            <span>Resolved: {resolvedDate}</span>
          </div>
        )}
      </div>
      
      {complaint.imageUrl && (
        <div className="h-40 overflow-hidden">
          <img 
            src={complaint.imageUrl} 
            alt={complaint.title} 
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="px-4 py-3 bg-gray-50 flex justify-between items-center">
        <div className="text-xs text-gray-500">
          ID: #{complaint.id}
        </div>
        
        {complaint.status === 'resolved' && !complaint.isRated && (
          <button 
            onClick={() => onRate(complaint)}
            className="text-sm font-medium text-green-600 hover:text-green-700"
          >
            <i className="fas fa-star mr-1"></i>
            Rate Work
          </button>
        )}
        
        {complaint.status === 'resolved' && complaint.isRated && (
          <div className="text-sm text-yellow-600">
            <i className="fas fa-star mr-1"></i>
            Rated
          </div>
        )}
      </div>
    </motion.div>
  );
};

const RatingModal = ({ isOpen, onClose, complaint, onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) return;
    
    setIsSubmitting(true);
    await onSubmit(complaint.id, rating, review);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4">
        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>
        
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-lg shadow-xl overflow-hidden w-full max-w-md z-10"
        >
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Rate the Resolution</h3>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                How satisfied are you with the cleanup?
              </label>
              <div className="flex items-center justify-center text-2xl">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    className="mx-1 focus:outline-none"
                  >
                    <i className={`${
                      star <= (hoveredRating || rating) 
                        ? 'fas fa-star text-yellow-400' 
                        : 'far fa-star text-gray-300'
                    }`}></i>
                  </button>
                ))}
              </div>
              <div className="text-center text-sm mt-2 text-gray-500">
                {rating === 1 && "Poor"}
                {rating === 2 && "Fair"}
                {rating === 3 && "Good"}
                {rating === 4 && "Very Good"}
                {rating === 5 && "Excellent"}
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="review" className="block text-sm font-medium text-gray-700 mb-2">
                Your Comments (Optional)
              </label>
              <textarea
                id="review"
                value={review}
                onChange={(e) => setReview(e.target.value)}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                placeholder="Share your experience with the resolution..."
              ></textarea>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={rating === 0 || isSubmitting}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Submitting...
                  </>
                ) : "Submit Rating"}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

const FilterButtons = ({ activeFilter, setActiveFilter }) => {
  const filters = [
    { value: 'all', label: 'All', icon: 'fa-list' },
    { value: 'pending', label: 'Pending', icon: 'fa-clock' },
    { value: 'in-progress', label: 'In Progress', icon: 'fa-spinner' },
    { value: 'resolved', label: 'Resolved', icon: 'fa-check-circle' }
  ];
  
  return (
    <div className="flex flex-wrap gap-2">
      {filters.map((filter) => (
        <button
          key={filter.value}
          onClick={() => setActiveFilter(filter.value)}
          className={`px-3 py-2 rounded-md text-sm font-medium flex items-center ${
            activeFilter === filter.value
              ? 'bg-green-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          } transition-colors`}
        >
          <i className={`fas ${filter.icon} mr-2`}></i>
          {filter.label}
        </button>
      ))}
    </div>
  );
};

const TrackComplaints = () => {
  const { user } = useAuth();
  const { submitRating } = useComplaint();
  const { toast } = useToast();
  
  const [activeFilter, setActiveFilter] = useState('all');
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'map'
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
  
  // Fetch user complaints
  const { data: userComplaints = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/complaints', { userId: user?.id }],
    queryFn: () => apiRequest('GET', `/api/complaints?userId=${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });
  
  // Fetch ratings to check which complaints have been rated
  const { data: ratings = [] } = useQuery({
    queryKey: ['/api/ratings/user', { userId: user?.id }],
    queryFn: () => apiRequest('GET', `/api/ratings?userId=${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });
  
  // Add isRated flag to complaints
  const complaintsWithRatingStatus = userComplaints.map(complaint => ({
    ...complaint,
    isRated: ratings.some(rating => rating.complaintId === complaint.id)
  }));
  
  // Filter complaints based on active filter
  const filteredComplaints = activeFilter === 'all'
    ? complaintsWithRatingStatus
    : complaintsWithRatingStatus.filter(complaint => complaint.status === activeFilter);
  
  // Prepare markers for map view
  const mapMarkers = filteredComplaints.map(complaint => ({
    lat: parseFloat(complaint.latitude),
    lng: parseFloat(complaint.longitude),
    status: complaint.status,
    title: complaint.title,
    info: `
      <div class="p-2">
        <h3 class="font-medium">${complaint.title}</h3>
        <p class="text-sm text-gray-600">${complaint.location}</p>
        <p class="text-xs text-gray-500 mt-1">Status: ${complaint.status}</p>
      </div>
    `
  }));
  
  const handleRateButtonClick = (complaint) => {
    setSelectedComplaint(complaint);
    setIsRatingModalOpen(true);
  };
  
  const handleRatingSubmit = async (complaintId, rating, review) => {
    try {
      const ratingData = {
        complaintId,
        userId: user.id,
        officialId: selectedComplaint.officialId,
        rating,
        review: review || null
      };
      
      await submitRating(ratingData);
      
      // Refetch complaints to update the UI
      refetch();
      
      toast({
        title: "Rating Submitted",
        description: "Thank you for your feedback!"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit rating. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="p-6">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <h2 className="text-2xl font-bold text-gray-800">Your Complaints</h2>
        
        <div className="flex space-x-3">
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-2 rounded-md text-sm font-medium ${
              viewMode === 'list'
                ? 'bg-green-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <i className="fas fa-list-ul mr-2"></i>
            List View
          </button>
          
          <button
            onClick={() => setViewMode('map')}
            className={`px-3 py-2 rounded-md text-sm font-medium ${
              viewMode === 'map'
                ? 'bg-green-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <i className="fas fa-map-marked-alt mr-2"></i>
            Map View
          </button>
        </div>
      </div>
      
      <div className="mb-6">
        <FilterButtons activeFilter={activeFilter} setActiveFilter={setActiveFilter} />
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center min-h-[300px]">
          <div className="text-center">
            <i className="fas fa-circle-notch fa-spin text-green-600 text-3xl mb-3"></i>
            <p className="text-gray-600">Loading your complaints...</p>
          </div>
        </div>
      ) : filteredComplaints.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <i className="fas fa-search text-gray-400 text-4xl mb-3"></i>
          <h3 className="text-xl font-medium text-gray-900 mb-2">No complaints found</h3>
          <p className="text-gray-600">
            {activeFilter === 'all'
              ? "You haven't submitted any complaints yet."
              : `You don't have any ${activeFilter} complaints.`}
          </p>
        </div>
      ) : viewMode === 'list' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredComplaints.map(complaint => (
            <ComplaintCard
              key={complaint.id}
              complaint={complaint}
              onRate={handleRateButtonClick}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="h-[70vh] w-full">
            <GoogleMapComponent
              markers={mapMarkers}
              defaultZoom={12}
              height="100%"
            />
          </div>
          <div className="p-4 bg-gray-50 flex items-center justify-center space-x-6">
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-red-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Pending</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">In Progress</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Resolved</span>
            </div>
          </div>
        </div>
      )}
      
      <RatingModal
        isOpen={isRatingModalOpen}
        onClose={() => setIsRatingModalOpen(false)}
        complaint={selectedComplaint}
        onSubmit={handleRatingSubmit}
      />
    </div>
  );
};

export default TrackComplaints;
