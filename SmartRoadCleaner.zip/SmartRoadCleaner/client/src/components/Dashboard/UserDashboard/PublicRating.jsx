import { useState, useEffect } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { useComplaint } from '../../../hooks/useComplaint';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../../lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useMaps } from '../../../hooks/useMaps';
import GoogleMapComponent from '../../Maps/GoogleMapComponent';

const RatingStars = ({ rating, totalRatings, size = 'normal' }) => {
  const stars = [];
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  
  // Size classes
  const sizeClass = size === 'large' ? 'text-xl' : size === 'small' ? 'text-xs' : 'text-sm';
  
  // Add full stars
  for (let i = 0; i < fullStars; i++) {
    stars.push(<i key={`full-${i}`} className="fas fa-star text-yellow-400"></i>);
  }
  
  // Add half star if needed
  if (hasHalfStar) {
    stars.push(<i key="half" className="fas fa-star-half-alt text-yellow-400"></i>);
  }
  
  // Add empty stars
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
  for (let i = 0; i < emptyStars; i++) {
    stars.push(<i key={`empty-${i}`} className="far fa-star text-yellow-400"></i>);
  }
  
  return (
    <div className="flex items-center">
      <div className={`flex ${sizeClass}`}>
        {stars}
      </div>
      {totalRatings !== undefined && (
        <span className="ml-2 text-xs text-gray-500">({totalRatings})</span>
      )}
    </div>
  );
};

const RoadCard = ({ road, onRate }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white rounded-lg shadow-sm overflow-hidden"
    >
      <div className="h-40 bg-gray-200 relative">
        <img
          src="https://images.unsplash.com/photo-1565114216457-a9d0666b7e4a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
          alt="Road view"
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-1">{road.roadName}</h3>
        
        <div className="flex items-center mb-3">
          <RatingStars rating={road.avgRating} totalRatings={road.totalRatings} />
        </div>
        
        <p className="text-sm text-gray-600 mb-4">
          {road.recentReview || "This road has been recently cleaned and maintained."}
        </p>
        
        <button
          onClick={() => onRate(road)}
          className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors flex items-center justify-center"
        >
          <i className="fas fa-star mr-2"></i>
          Rate This Road
        </button>
      </div>
    </motion.div>
  );
};

const RateRoadModal = ({ isOpen, onClose, road, onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!isOpen) return null;
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) return;
    
    setIsSubmitting(true);
    await onSubmit(road.roadName, rating, review);
    setIsSubmitting(false);
    onClose();
  };
  
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4">
        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>
        
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-lg shadow-xl overflow-hidden w-full max-w-md z-10"
        >
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Rate {road.roadName}</h3>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                How would you rate the cleanliness of this road?
              </label>
              <div className="flex items-center justify-center text-2xl">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    className="mx-1 focus:outline-none"
                  >
                    <i className={`${
                      star <= (hoveredRating || rating) 
                        ? 'fas fa-star text-yellow-400' 
                        : 'far fa-star text-gray-300'
                    }`}></i>
                  </button>
                ))}
              </div>
              <div className="text-center text-sm mt-2 text-gray-500">
                {rating === 1 && "Poor - Needs immediate attention"}
                {rating === 2 && "Fair - Could be cleaner"}
                {rating === 3 && "Good - Reasonably clean"}
                {rating === 4 && "Very Good - Clean and well-maintained"}
                {rating === 5 && "Excellent - Spotless and perfectly maintained"}
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="review" className="block text-sm font-medium text-gray-700 mb-2">
                Your Review (Optional)
              </label>
              <textarea
                id="review"
                value={review}
                onChange={(e) => setReview(e.target.value)}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                placeholder="Share your thoughts on the road's cleanliness..."
              ></textarea>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={rating === 0 || isSubmitting}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Submitting...
                  </>
                ) : "Submit Rating"}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

const PublicRating = () => {
  const { user } = useAuth();
  const { submitRoadRating } = useComplaint();
  const { toast } = useToast();
  const { isLoaded: mapsLoaded } = useMaps();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'map'
  const [sortBy, setSortBy] = useState('rating'); // 'rating', 'name', 'reviews'
  const [selectedRoad, setSelectedRoad] = useState(null);
  const [isRateModalOpen, setIsRateModalOpen] = useState(false);
  
  // Fetch all road ratings
  const { data: roadRatings = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/road-ratings'],
    queryFn: () => apiRequest('GET', '/api/road-ratings').then(res => res.json())
  });
  
  // Process the raw ratings data to get aggregated road data
  const processRoadData = (ratings) => {
    const roadMap = new Map();
    
    ratings.forEach(rating => {
      if (!roadMap.has(rating.roadName)) {
        roadMap.set(rating.roadName, {
          roadName: rating.roadName,
          ratings: [],
          reviews: []
        });
      }
      
      const road = roadMap.get(rating.roadName);
      road.ratings.push(rating.rating);
      if (rating.review) {
        road.reviews.push(rating.review);
      }
    });
    
    return Array.from(roadMap.values()).map(road => ({
      roadName: road.roadName,
      avgRating: road.ratings.reduce((sum, rating) => sum + rating, 0) / road.ratings.length,
      totalRatings: road.ratings.length,
      recentReview: road.reviews.length > 0 ? road.reviews[0] : null
    }));
  };
  
  const roads = processRoadData(roadRatings);
  
  // Filter roads based on search term
  const filteredRoads = roads.filter(road => 
    road.roadName.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Sort roads based on sort option
  const sortedRoads = [...filteredRoads].sort((a, b) => {
    if (sortBy === 'rating') {
      return b.avgRating - a.avgRating;
    } else if (sortBy === 'name') {
      return a.roadName.localeCompare(b.roadName);
    } else if (sortBy === 'reviews') {
      return b.totalRatings - a.totalRatings;
    }
    return 0;
  });
  
  // Prepare markers for map view
  const mapMarkers = sortedRoads.map((road, index) => ({
    lat: parseFloat(35.6895 + Math.random() * 0.02 - 0.01), // Mock data - in a real app, roads would have coordinates
    lng: parseFloat(139.6917 + Math.random() * 0.02 - 0.01),
    status: road.avgRating >= 4 ? 'resolved' : road.avgRating >= 3 ? 'in-progress' : 'pending',
    title: road.roadName,
    info: `
      <div class="p-2">
        <h3 class="font-medium">${road.roadName}</h3>
        <p class="text-xs text-yellow-500 mt-1">
          ${'★'.repeat(Math.round(road.avgRating))}${'☆'.repeat(5 - Math.round(road.avgRating))}
          (${road.totalRatings})
        </p>
      </div>
    `
  }));
  
  const handleRateRoad = (road) => {
    setSelectedRoad(road);
    setIsRateModalOpen(true);
  };
  
  const handleRatingSubmit = async (roadName, rating, review) => {
    try {
      const roadRatingData = {
        roadName,
        userId: user.id,
        rating,
        review: review || null
      };
      
      await submitRoadRating(roadRatingData);
      
      // Refetch road ratings to update the UI
      refetch();
      
      toast({
        title: "Rating Submitted",
        description: "Thank you for rating this road!"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit rating. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Public Road Ratings</h2>
        <p className="text-gray-600">Rate and view the cleanliness of roads in your community</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for a road..."
              className="w-full md:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            />
            <div className="absolute left-3 top-2.5 text-gray-400">
              <i className="fas fa-search"></i>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div>
              <label htmlFor="sort-by" className="block text-sm font-medium text-gray-700 mr-2 inline-block">
                Sort by:
              </label>
              <select
                id="sort-by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="inline-block w-auto border border-gray-300 rounded-md shadow-sm py-2 pl-3 pr-10 text-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                <option value="rating">Highest Rated</option>
                <option value="name">Road Name</option>
                <option value="reviews">Most Reviews</option>
              </select>
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`w-10 h-10 flex items-center justify-center rounded-md ${
                  viewMode === 'grid'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <i className="fas fa-th"></i>
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`w-10 h-10 flex items-center justify-center rounded-md ${
                  viewMode === 'map'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <i className="fas fa-map-marked-alt"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center min-h-[300px]">
          <div className="text-center">
            <i className="fas fa-circle-notch fa-spin text-green-600 text-3xl mb-3"></i>
            <p className="text-gray-600">Loading road ratings...</p>
          </div>
        </div>
      ) : sortedRoads.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <i className="fas fa-road text-gray-400 text-4xl mb-3"></i>
          <h3 className="text-xl font-medium text-gray-900 mb-2">No rated roads found</h3>
          <p className="text-gray-600 mb-4">
            {searchTerm
              ? `No roads matching "${searchTerm}" were found`
              : "There are no rated roads yet. Be the first to rate a road!"}
          </p>
          <button
            onClick={() => setIsRateModalOpen(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            <i className="fas fa-star mr-2"></i>
            Rate a Road
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedRoads.map((road, index) => (
            <RoadCard
              key={index}
              road={road}
              onRate={handleRateRoad}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="h-[70vh] w-full">
            {mapsLoaded ? (
              <GoogleMapComponent
                markers={mapMarkers}
                defaultZoom={14}
                height="100%"
              />
            ) : (
              <div className="h-full w-full flex items-center justify-center bg-gray-100">
                <div className="text-center">
                  <i className="fas fa-spinner fa-spin text-green-600 text-3xl mb-3"></i>
                  <p className="text-gray-600">Loading map...</p>
                </div>
              </div>
            )}
          </div>
          <div className="p-4 bg-gray-50 flex items-center justify-center space-x-6">
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Excellent (4-5 ★)</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Good (3-4 ★)</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-3 h-3 bg-red-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-600">Needs Improvement (1-3 ★)</span>
            </div>
          </div>
        </div>
      )}
      
      <RateRoadModal
        isOpen={isRateModalOpen}
        onClose={() => setIsRateModalOpen(false)}
        road={selectedRoad || { roadName: 'New Road' }}
        onSubmit={handleRatingSubmit}
      />
      
      <div className="bg-green-50 rounded-lg p-4 mt-8">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="fas fa-lightbulb text-green-600 text-xl"></i>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-800">Why rate roads?</h3>
            <div className="mt-2 text-sm text-green-700">
              <ul className="list-disc pl-5 space-y-1">
                <li>Help municipal workers identify areas that need attention</li>
                <li>Recognize the efforts of cleaning staff in well-maintained areas</li>
                <li>Provide feedback to improve the cleanliness of your city</li>
                <li>Track changes in road cleanliness over time</li>
                <li>Build a community-driven database of road cleanliness information</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PublicRating;
