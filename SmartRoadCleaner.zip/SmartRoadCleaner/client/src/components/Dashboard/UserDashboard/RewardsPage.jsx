import { useState, useEffect } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../../lib/queryClient';
import { motion } from 'framer-motion';

const UserRankCard = ({ rank, username, points, profileImage, isCurrentUser }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className={`bg-white rounded-lg shadow-sm p-4 flex items-center ${isCurrentUser ? 'border-2 border-green-500' : ''}`}
    >
      <div className="flex-shrink-0 mr-4">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
          rank === 1 ? 'bg-yellow-500' : rank === 2 ? 'bg-gray-400' : rank === 3 ? 'bg-yellow-700' : 'bg-gray-300'
        }`}>
          {rank}
        </div>
      </div>
      <div className="flex-shrink-0 mr-4">
        <img
          src={profileImage || `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=random`}
          alt={username}
          className="h-12 w-12 rounded-full object-cover"
        />
      </div>
      <div className="flex-1">
        <div className="flex items-center">
          <h3 className="text-gray-900 font-medium">
            {username}
            {isCurrentUser && <span className="ml-2 text-xs text-gray-500">(You)</span>}
          </h3>
          {rank <= 3 && (
            <span className="ml-2">
              {rank === 1 && <i className="fas fa-crown text-yellow-500"></i>}
              {rank === 2 && <i className="fas fa-medal text-gray-400"></i>}
              {rank === 3 && <i className="fas fa-award text-yellow-700"></i>}
            </span>
          )}
        </div>
        <div className="flex items-center mt-1">
          <div className="text-sm text-gray-500">
            <i className="fas fa-star mr-1 text-green-600"></i>
            {points} points
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const AchievementCard = ({ title, description, icon, progress, maxProgress, achieved }) => {
  const progressPercentage = (progress / maxProgress) * 100;
  
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className={`bg-white rounded-lg shadow-sm p-5 ${achieved ? 'border-green-500 border-2' : ''}`}
    >
      <div className="flex items-center mb-3">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
          achieved ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
        }`}>
          <i className={`${icon} text-2xl`}></i>
        </div>
        <div className="ml-4">
          <h3 className="text-gray-900 font-medium">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
      </div>
      
      <div className="mt-3">
        <div className="flex justify-between mb-1 text-xs text-gray-600">
          <span>{progress} / {maxProgress}</span>
          {achieved && <span className="text-green-600 font-medium">Completed!</span>}
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className={`h-2 rounded-full ${achieved ? 'bg-green-600' : 'bg-blue-500'}`} 
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>
    </motion.div>
  );
};

const Certificate = ({ user, complaints, dateIssued }) => {
  const formattedDate = new Date(dateIssued).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 400, damping: 10 }}
      className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg shadow-md p-8 border border-green-200"
    >
      <div className="border-4 border-green-600 rounded-lg p-8 bg-white shadow-inner text-center">
        <div className="text-green-700 text-3xl mb-2">
          <i className="fas fa-award"></i>
        </div>
        <h2 className="text-2xl font-bold text-green-800 mb-2">Certificate of Appreciation</h2>
        <p className="text-gray-600 mb-6">This is to certify that</p>
        <h3 className="text-xl font-bold text-gray-800 mb-6">{user.fullName || user.username}</h3>
        <p className="text-gray-600 mb-4">
          Has made a significant contribution to improve our city's cleanliness by reporting
          <span className="font-bold text-green-700 mx-1">{complaints}</span>
          issues that have been successfully resolved.
        </p>
        <p className="text-gray-600 mb-6">
          Your commitment to maintaining a clean environment is commendable and inspires others to follow suit.
        </p>
        <div className="mb-6 mt-8">
          <div className="h-0.5 w-40 bg-gray-400 mx-auto mb-2"></div>
          <p className="text-sm text-gray-500">Smart Road Cleanliness Tracker</p>
        </div>
        <p className="text-sm text-gray-500">Issued on: {formattedDate}</p>
      </div>
    </motion.div>
  );
};

const RewardsPage = () => {
  const { user } = useAuth();
  const [leaderboardFilter, setLeaderboardFilter] = useState('all-time');
  
  // Fetch all users for leaderboard
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: () => apiRequest('GET', '/api/users').then(res => res.json())
  });
  
  // Fetch complaints to calculate achievements
  const { data: complaints = [], isLoading: complaintsLoading } = useQuery({
    queryKey: ['/api/complaints', { userId: user?.id }],
    queryFn: () => apiRequest('GET', `/api/complaints?userId=${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });
  
  // Sort users by points for leaderboard
  const leaderboardUsers = [...users].sort((a, b) => (b.points || 0) - (a.points || 0))
    .map((user, index) => ({ ...user, rank: index + 1 }));
  
  // Find current user in leaderboard
  const currentUserRank = leaderboardUsers.find(u => u.id === user?.id)?.rank || 0;
  
  // Calculate user achievements
  const completedComplaints = complaints.filter(c => c.status === 'resolved').length;
  const pendingComplaints = complaints.filter(c => c.status === 'pending').length;
  const totalComplaints = complaints.length;
  
  // Define achievements
  const achievements = [
    {
      id: 1,
      title: 'First Report',
      description: 'Submit your first cleanliness complaint',
      icon: 'fas fa-flag',
      progress: totalComplaints,
      maxProgress: 1,
      achieved: totalComplaints >= 1
    },
    {
      id: 2,
      title: 'Active Citizen',
      description: 'Submit 5 cleanliness complaints',
      icon: 'fas fa-user-check',
      progress: totalComplaints,
      maxProgress: 5,
      achieved: totalComplaints >= 5
    },
    {
      id: 3,
      title: 'Cleanliness Champion',
      description: 'Have 10 complaints successfully resolved',
      icon: 'fas fa-trophy',
      progress: completedComplaints,
      maxProgress: 10,
      achieved: completedComplaints >= 10
    },
    {
      id: 4,
      title: 'Community Guardian',
      description: 'Submit complaints in at least 3 different areas',
      icon: 'fas fa-shield-alt',
      progress: Math.min(3, new Set(complaints.map(c => c.location.split(',')[0])).size),
      maxProgress: 3,
      achieved: new Set(complaints.map(c => c.location.split(',')[0])).size >= 3
    }
  ];
  
  // Determine if user qualifies for certificate
  const qualifiesForCertificate = completedComplaints >= 5;
  
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Your Rewards & Achievements</h2>
        <p className="text-gray-600">Track your progress and see how you compare with other citizens</p>
      </div>
      
      {/* User Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white rounded-lg shadow-sm p-6"
        >
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-full">
              <i className="fas fa-trophy text-green-600"></i>
            </div>
            <div className="ml-4">
              <h3 className="text-gray-500 text-sm">Points Earned</h3>
              <p className="text-2xl font-semibold text-gray-800">{user?.points || 0}</p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white rounded-lg shadow-sm p-6"
        >
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-full">
              <i className="fas fa-medal text-blue-600"></i>
            </div>
            <div className="ml-4">
              <h3 className="text-gray-500 text-sm">Your Rank</h3>
              <p className="text-2xl font-semibold text-gray-800">
                {currentUserRank > 0 ? `#${currentUserRank}` : 'N/A'}
              </p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white rounded-lg shadow-sm p-6"
        >
          <div className="flex items-center">
            <div className="bg-purple-100 p-3 rounded-full">
              <i className="fas fa-check-circle text-purple-600"></i>
            </div>
            <div className="ml-4">
              <h3 className="text-gray-500 text-sm">Achievements</h3>
              <p className="text-2xl font-semibold text-gray-800">
                {achievements.filter(a => a.achieved).length}/{achievements.length}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Leaderboard */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-800">Leaderboard</h3>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setLeaderboardFilter('all-time')}
              className={`px-3 py-1 text-xs rounded-md ${
                leaderboardFilter === 'all-time' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All-Time
            </button>
            <button
              onClick={() => setLeaderboardFilter('monthly')}
              className={`px-3 py-1 text-xs rounded-md ${
                leaderboardFilter === 'monthly' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              This Month
            </button>
            <button
              onClick={() => setLeaderboardFilter('weekly')}
              className={`px-3 py-1 text-xs rounded-md ${
                leaderboardFilter === 'weekly' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              This Week
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {usersLoading ? (
            <div className="text-center py-4">
              <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
              <p className="mt-2 text-gray-600">Loading leaderboard...</p>
            </div>
          ) : (
            <div className="space-y-4">
              {leaderboardUsers.slice(0, 10).map(leaderboardUser => (
                <UserRankCard
                  key={leaderboardUser.id}
                  rank={leaderboardUser.rank}
                  username={leaderboardUser.fullName || leaderboardUser.username}
                  points={leaderboardUser.points || 0}
                  profileImage={leaderboardUser.profilePicture}
                  isCurrentUser={leaderboardUser.id === user?.id}
                />
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Achievements */}
      <h3 className="text-xl font-medium text-gray-800 mb-4">Your Achievements</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {achievements.map(achievement => (
          <AchievementCard
            key={achievement.id}
            title={achievement.title}
            description={achievement.description}
            icon={achievement.icon}
            progress={achievement.progress}
            maxProgress={achievement.maxProgress}
            achieved={achievement.achieved}
          />
        ))}
      </div>
      
      {/* Certificate */}
      {qualifiesForCertificate && (
        <div className="mb-8">
          <h3 className="text-xl font-medium text-gray-800 mb-4">Your Certificate</h3>
          <Certificate
            user={user}
            complaints={completedComplaints}
            dateIssued={new Date()}
          />
        </div>
      )}
      
      {/* Information Box */}
      <div className="bg-green-50 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="fas fa-lightbulb text-green-600 text-xl"></i>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-800">How to earn more points</h3>
            <div className="mt-2 text-sm text-green-700">
              <ul className="list-disc pl-5 space-y-1">
                <li>Report cleanliness issues (+5 points per report)</li>
                <li>Get your reported issues resolved (+10 points)</li>
                <li>Join cleanup collaborations (+15 points)</li>
                <li>Rate resolved complaints (+2 points)</li>
                <li>Have your report identified as a critical issue (+20 points)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RewardsPage;
