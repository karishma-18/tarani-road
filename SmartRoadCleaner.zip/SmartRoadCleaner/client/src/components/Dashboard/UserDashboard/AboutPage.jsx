import { motion } from 'framer-motion';

const AboutPage = () => {
  return (
    <div className="p-6">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">About Smart Road Cleanliness Tracker</h2>
          
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 pr-0 md:pr-4 mb-4 md:mb-0">
              <p className="text-gray-600 mb-4">
                Smart Road Cleanliness Tracker is an innovative platform designed to connect citizens with municipal authorities
                to ensure cleaner roads and a greener environment.
              </p>
              <p className="text-gray-600 mb-4">
                Our mission is to empower citizens to take an active role in maintaining their community's cleanliness
                while providing municipal authorities with real-time data to improve their services.
              </p>
              <p className="text-gray-600 mb-4">
                Through citizen reporting, collaborative cleanup events, and a rewards system, we're building
                a cleaner, more sustainable future together.
              </p>
            </div>
            <div className="md:w-1/2 mt-4 md:mt-0">
              <img 
                src="https://images.unsplash.com/photo-1598886221321-91c441ac1927?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" 
                alt="Clean city" 
                className="rounded-lg w-full h-64 object-cover"
              />
            </div>
          </div>
          
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl font-semibold text-gray-800 mt-8 mb-3"
          >
            How We Help
          </motion.h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-green-50 p-4 rounded-lg"
            >
              <div className="text-green-600 text-2xl mb-2">
                <i className="fas fa-map-marked-alt"></i>
              </div>
              <h4 className="font-medium text-gray-800 mb-2">Identifying Problem Areas</h4>
              <p className="text-gray-600 text-sm">
                We help municipal authorities identify cleanliness hotspots that require immediate attention.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-green-50 p-4 rounded-lg"
            >
              <div className="text-green-600 text-2xl mb-2">
                <i className="fas fa-users"></i>
              </div>
              <h4 className="font-medium text-gray-800 mb-2">Community Engagement</h4>
              <p className="text-gray-600 text-sm">
                We encourage citizens to volunteer and participate in cleanup drives to keep their communities clean.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-green-50 p-4 rounded-lg"
            >
              <div className="text-green-600 text-2xl mb-2">
                <i className="fas fa-award"></i>
              </div>
              <h4 className="font-medium text-gray-800 mb-2">Recognition System</h4>
              <p className="text-gray-600 text-sm">
                We recognize and reward citizens and officials who contribute to making our city cleaner.
              </p>
            </motion.div>
          </div>
          
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="text-xl font-semibold text-gray-800 mt-8 mb-3"
          >
            Our Vision
          </motion.h3>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="text-gray-600 mb-4"
          >
            We envision a world where communities take collective responsibility for their environment,
            where municipal authorities and citizens work hand in hand to create cleaner, greener, and more
            sustainable urban spaces.
          </motion.p>
          
          <div className="my-8">
            <img 
              src="https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
              alt="Sustainable city" 
              className="w-full h-64 object-cover rounded-lg"
            />
          </div>
          
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-xl font-semibold text-gray-800 mt-8 mb-3"
          >
            Key Features
          </motion.h3>
          
          <div className="space-y-4">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.9 }}
              className="flex"
            >
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600">
                  <i className="fas fa-camera"></i>
                </div>
              </div>
              <div className="ml-4">
                <h4 className="text-lg font-medium text-gray-900">Easy Reporting</h4>
                <p className="mt-2 text-base text-gray-600">
                  Citizens can report cleanliness issues with just a few taps - uploading photos and marking locations on a map.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1.0 }}
              className="flex"
            >
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600">
                  <i className="fas fa-tasks"></i>
                </div>
              </div>
              <div className="ml-4">
                <h4 className="text-lg font-medium text-gray-900">Real-time Tracking</h4>
                <p className="mt-2 text-base text-gray-600">
                  Track the status of reported issues in real-time, from submission to resolution.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1.1 }}
              className="flex"
            >
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600">
                  <i className="fas fa-users"></i>
                </div>
              </div>
              <div className="ml-4">
                <h4 className="text-lg font-medium text-gray-900">Community Collaboration</h4>
                <p className="mt-2 text-base text-gray-600">
                  Join or create cleanup events in your neighborhood and make a direct impact.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1.2 }}
              className="flex"
            >
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600">
                  <i className="fas fa-trophy"></i>
                </div>
              </div>
              <div className="ml-4">
                <h4 className="text-lg font-medium text-gray-900">Rewards & Recognition</h4>
                <p className="mt-2 text-base text-gray-600">
                  Earn points, achievements, and certificates for your contributions to a cleaner city.
                </p>
              </div>
            </motion.div>
          </div>
          
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.3 }}
            className="text-xl font-semibold text-gray-800 mt-8 mb-4"
          >
            Join Our Mission
          </motion.h3>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.4 }}
            className="text-gray-600 mb-4"
          >
            We invite you to be part of this transformative journey. Together, we can create cleaner, more
            livable cities for current and future generations. Every report, every cleanup event, every rating
            contributes to building a better environment for all.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.5 }}
            className="mt-6 flex justify-center"
          >
            <button className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
              <i className="fas fa-plus-circle mr-2"></i>
              Report Your First Issue
            </button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutPage;
