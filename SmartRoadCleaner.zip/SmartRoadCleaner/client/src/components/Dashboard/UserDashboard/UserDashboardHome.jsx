import { useState, useEffect } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { apiRequest } from '../../../lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import GoogleMapComponent from '../../Maps/GoogleMapComponent';

const StatCard = ({ icon, title, value, color }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center">
        <div className={`bg-${color}-100 p-3 rounded-full`}>
          <i className={`fas ${icon} text-${color}-600`}></i>
        </div>
        <div className="ml-4">
          <h3 className="text-gray-500 text-sm">{title}</h3>
          <p className="text-2xl font-semibold text-gray-800">{value}</p>
        </div>
      </div>
    </div>
  );
};

const ComplaintItem = ({ complaint }) => {
  return (
    <div className="flex items-start">
      <div className="flex-shrink-0">
        <img 
          className="h-10 w-10 rounded-md object-cover" 
          src={complaint.imageUrl || "https://via.placeholder.com/40?text=No+Image"} 
          alt={complaint.title} 
        />
      </div>
      <div className="ml-4 flex-1">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium text-gray-900">{complaint.title}</h4>
          <span className={`px-2 py-1 text-xs rounded-full ${
            complaint.status === 'pending' 
              ? 'bg-yellow-100 text-yellow-800' 
              : complaint.status === 'in-progress' 
                ? 'bg-blue-100 text-blue-800' 
                : 'bg-green-100 text-green-800'
          }`}>
            {complaint.status.charAt(0).toUpperCase() + complaint.status.slice(1)}
          </span>
        </div>
        <p className="mt-1 text-sm text-gray-600">{complaint.location}</p>
      </div>
    </div>
  );
};

const EventItem = ({ event }) => {
  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm font-medium text-gray-900">{event.title}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-600">{event.location}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-600">
          {new Date(event.date).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          event.isFull ? 'bg-gray-100 text-gray-800' : 'bg-green-100 text-green-800'
        }`}>
          {event.isFull ? 'Full' : 'Open'}
        </span>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm">
        {event.isFull ? (
          <button className="text-gray-400 cursor-not-allowed">Full</button>
        ) : (
          <button className="text-green-700 hover:text-green-500 font-medium">Join</button>
        )}
      </td>
    </tr>
  );
};

const UserDashboardHome = () => {
  const { user } = useAuth();
  const userId = user?.id;
  
  const { data: complaints = [], isLoading: complaintsLoading } = useQuery({
    queryKey: ['/api/complaints', { userId }],
    queryFn: () => apiRequest('GET', `/api/complaints?userId=${userId}`).then(res => res.json()),
    enabled: !!userId
  });
  
  const { data: collaborations = [], isLoading: collaborationsLoading } = useQuery({
    queryKey: ['/api/collaborations'],
    queryFn: () => apiRequest('GET', '/api/collaborations').then(res => res.json())
  });

  // Derived stats
  const pendingComplaints = complaints.filter(c => c.status === 'pending').length;
  const resolvedComplaints = complaints.filter(c => c.status === 'resolved').length;
  const upcomingEvents = collaborations
    .filter(c => new Date(c.date) > new Date())
    .map(c => ({
      ...c,
      isFull: false // In a real app, this would be calculated based on members
    }));

  const complaintLocations = complaints.map(complaint => ({
    lat: parseFloat(complaint.latitude),
    lng: parseFloat(complaint.longitude),
    status: complaint.status
  }));

  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <StatCard 
          icon="fa-clipboard-list" 
          title="Total Complaints" 
          value={complaints.length} 
          color="green"
        />
        <StatCard 
          icon="fa-hourglass-half" 
          title="Pending" 
          value={pendingComplaints} 
          color="yellow"
        />
        <StatCard 
          icon="fa-check-circle" 
          title="Resolved" 
          value={resolvedComplaints} 
          color="green"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Complaints */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-800">Recent Complaints</h3>
          </div>
          <div className="p-6">
            {complaintsLoading ? (
              <div className="text-center py-4">
                <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
                <p className="mt-2 text-gray-600">Loading complaints...</p>
              </div>
            ) : complaints.length > 0 ? (
              <div className="space-y-4">
                {complaints.slice(0, 3).map(complaint => (
                  <ComplaintItem key={complaint.id} complaint={complaint} />
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-600">No complaints found.</p>
              </div>
            )}
            
            <div className="mt-6">
              <Link href="/user-dashboard/track">
                <a className="text-green-700 hover:text-green-500 font-medium text-sm">View all complaints →</a>
              </Link>
            </div>
          </div>
        </div>
        
        {/* Complaint Map */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-800">Complaint Map</h3>
          </div>
          <div className="p-6">
            <div className="h-[300px] w-full rounded-lg overflow-hidden">
              <GoogleMapComponent 
                markers={complaintLocations}
                defaultZoom={12}
              />
            </div>
            
            <div className="mt-4 flex items-center text-sm text-gray-600">
              <span className="inline-block w-3 h-3 bg-red-500 rounded-full mr-1"></span>
              <span className="mr-4">Pending</span>
              
              <span className="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-1"></span>
              <span className="mr-4">In Progress</span>
              
              <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span>
              <span>Resolved</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Upcoming Events */}
      <div className="mt-6 bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-800">Upcoming Cleanup Events</h3>
        </div>
        <div className="p-6">
          {collaborationsLoading ? (
            <div className="text-center py-4">
              <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
              <p className="mt-2 text-gray-600">Loading events...</p>
            </div>
          ) : upcomingEvents.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {upcomingEvents.map(event => (
                    <EventItem key={event.id} event={event} />
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-gray-600">No upcoming events found.</p>
              <Link href="/user-dashboard/collaborate">
                <a className="inline-block mt-2 text-green-700 hover:text-green-500">Create a cleanup event</a>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserDashboardHome;
