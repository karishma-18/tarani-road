import { useState, useRef } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../../lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { storage } from '../../../lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const StatCard = ({ icon, title, value, bgColor, textColor }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center">
        <div className={`${bgColor} p-3 rounded-full`}>
          <i className={`fas ${icon} ${textColor}`}></i>
        </div>
        <div className="ml-4">
          <h3 className="text-gray-500 text-sm">{title}</h3>
          <p className="text-2xl font-semibold text-gray-800">{value}</p>
        </div>
      </div>
    </div>
  );
};

const ProfilePage = () => {
  const { user, updateUserData } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(user?.profilePicture || '');
  
  const [formData, setFormData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    profileImage: null
  });
  
  // Fetch user complaints for statistics
  const { data: complaints = [] } = useQuery({
    queryKey: ['/api/complaints', { userId: user?.id }],
    queryFn: () => apiRequest('GET', `/api/complaints?userId=${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });
  
  // Calculate statistics
  const totalComplaints = complaints.length;
  const pendingComplaints = complaints.filter(c => c.status === 'pending').length;
  const resolvedComplaints = complaints.filter(c => c.status === 'resolved').length;
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, profileImage: file });
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  
  const handleEditToggle = () => {
    if (isEditing) {
      // Cancel editing - reset form data
      setFormData({
        fullName: user?.fullName || '',
        email: user?.email || '',
        phone: user?.phone || '',
        profileImage: null
      });
      setPreviewUrl(user?.profilePicture || '');
    }
    setIsEditing(!isEditing);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      let profilePictureUrl = user?.profilePicture;
      
      // Upload profile image if changed
      if (formData.profileImage) {
        const storageRef = ref(storage, `profiles/${user.id}_${Date.now()}`);
        const uploadResult = await uploadBytes(storageRef, formData.profileImage);
        profilePictureUrl = await getDownloadURL(uploadResult.ref);
      }
      
      // Update user data
      const updatedUserData = {
        fullName: formData.fullName,
        phone: formData.phone,
        profilePicture: profilePictureUrl
      };
      
      await updateUserData(user.id, updatedUserData);
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
      });
      
      setIsEditing(false);
    } catch (error) {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update profile",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="p-6">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="md:flex">
          <div className="md:flex-shrink-0 p-6 flex flex-col items-center md:w-64 bg-gray-50">
            <div className="relative group">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="w-32 h-32 rounded-full overflow-hidden mb-4 bg-gray-200"
              >
                <img
                  src={previewUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.fullName || user?.username)}&size=128&background=random`}
                  alt="Profile picture"
                  className="w-full h-full object-cover"
                />
              </motion.div>
              
              {isEditing && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current.click()}
                  className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <i className="fas fa-camera mr-2"></i>
                  Change Photo
                </button>
              )}
              
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
            </div>
            
            {!isEditing && (
              <>
                <h2 className="text-xl font-bold text-gray-900">{user?.fullName || user?.username}</h2>
                <p className="text-gray-500 mb-4">{user?.email}</p>
                <div className="flex items-center text-sm text-green-600 font-medium">
                  <i className="fas fa-award mr-2"></i>
                  <span>{user?.points || 0} points</span>
                </div>
                
                <button
                  onClick={handleEditToggle}
                  className="mt-6 w-full flex items-center justify-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <i className="fas fa-edit mr-2"></i>
                  Edit Profile
                </button>
              </>
            )}
          </div>
          
          <div className="p-6 flex-1">
            {isEditing ? (
              <form onSubmit={handleSubmit}>
                <h2 className="text-xl font-bold text-gray-900 mb-6">Edit Profile</h2>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 cursor-not-allowed"
                    />
                    <p className="mt-1 text-xs text-gray-500">Email cannot be changed</p>
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleEditToggle}
                    className="px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Saving...
                      </>
                    ) : "Save Changes"}
                  </button>
                </div>
              </form>
            ) : (
              <>
                <h2 className="text-xl font-bold text-gray-900 mb-6">Profile Information</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Full Name</h3>
                    <p className="mt-1 text-sm text-gray-900">{user?.fullName || 'Not set'}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Email Address</h3>
                    <p className="mt-1 text-sm text-gray-900">{user?.email}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Phone Number</h3>
                    <p className="mt-1 text-sm text-gray-900">{user?.phone || 'Not set'}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Account Type</h3>
                    <p className="mt-1 text-sm text-gray-900">
                      {user?.userType === 'user' ? 'Citizen' : user?.userType === 'official' ? 'Municipal Official' : 'Admin'}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Member Since</h3>
                    <p className="mt-1 text-sm text-gray-900">
                      {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <StatCard 
          icon="fa-clipboard-list" 
          title="Total Complaints" 
          value={totalComplaints}
          bgColor="bg-green-100"
          textColor="text-green-600"
        />
        <StatCard 
          icon="fa-hourglass-half" 
          title="Pending Issues" 
          value={pendingComplaints}
          bgColor="bg-yellow-100"
          textColor="text-yellow-600"
        />
        <StatCard 
          icon="fa-check-circle" 
          title="Resolved Issues" 
          value={resolvedComplaints}
          bgColor="bg-blue-100"
          textColor="text-blue-600"
        />
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Account Actions</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-gray-200">
            <div>
              <h4 className="text-sm font-medium text-gray-900">Change Password</h4>
              <p className="text-xs text-gray-500">Update your password to enhance security</p>
            </div>
            <button className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-100 transition-colors">
              Change
            </button>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-gray-200">
            <div>
              <h4 className="text-sm font-medium text-gray-900">Notification Preferences</h4>
              <p className="text-xs text-gray-500">Manage how you receive updates and alerts</p>
            </div>
            <button className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-100 transition-colors">
              Configure
            </button>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-gray-200">
            <div>
              <h4 className="text-sm font-medium text-gray-900">Privacy Settings</h4>
              <p className="text-xs text-gray-500">Control what information is visible to others</p>
            </div>
            <button className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-100 transition-colors">
              Review
            </button>
          </div>
          
          <div className="flex items-center justify-between py-3">
            <div>
              <h4 className="text-sm font-medium text-red-600">Delete Account</h4>
              <p className="text-xs text-gray-500">Permanently remove your account and all data</p>
            </div>
            <button className="px-3 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors">
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
