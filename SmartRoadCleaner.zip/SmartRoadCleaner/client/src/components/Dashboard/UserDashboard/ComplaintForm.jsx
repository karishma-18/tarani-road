import { useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../../../hooks/useAuth';
import { useMaps } from '../../../hooks/useMaps';
import GoogleMapComponent from '../../Maps/GoogleMapComponent';
import { useToast } from '@/hooks/use-toast';

const ComplaintForm = () => {
  const { user } = useAuth();
  const { geocodeAddress, reverseGeocode } = useMaps();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [addressInput, setAddressInput] = useState('');
  const fileInputRef = useRef(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    image: null,
    location: '',
    latitude: '',
    longitude: ''
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddressSearch = async (e) => {
    e.preventDefault();
    
    if (!addressInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter an address to search",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setLoading(true);
      const result = await geocodeAddress(addressInput);
      
      setSelectedLocation({
        lat: result.lat,
        lng: result.lng
      });
      
      setFormData({
        ...formData,
        location: result.formattedAddress,
        latitude: result.lat.toString(),
        longitude: result.lng.toString()
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to find the location. Please try a different address.",
        variant: "destructive"
      });
      console.error("Geocoding error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleMapClick = async (location) => {
    try {
      setLoading(true);
      const address = await reverseGeocode(location.lat, location.lng);
      
      setSelectedLocation(location);
      setFormData({
        ...formData,
        location: address,
        latitude: location.lat.toString(),
        longitude: location.lng.toString()
      });
      setAddressInput(address);
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get address for the selected location.",
        variant: "destructive"
      });
      console.error("Reverse geocoding error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.title || !formData.description || !formData.location || !formData.latitude || !formData.longitude) {
      toast({
        title: "Error",
        description: "Please fill in all required fields and select a location on the map.",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    
    try {
      // Create FormData object for file upload
      const data = new FormData();
      data.append('title', formData.title);
      data.append('description', formData.description);
      data.append('location', formData.location);
      data.append('latitude', formData.latitude);
      data.append('longitude', formData.longitude);
      data.append('userId', user.id);
      data.append('status', 'pending');
      
      if (formData.image) {
        data.append('image', formData.image);
      }
      
      // Send data to server
      const response = await fetch('/api/complaints', {
        method: 'POST',
        body: data
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit complaint');
      }
      
      toast({
        title: "Success",
        description: "Your complaint has been submitted successfully",
      });
      
      // Redirect to track complaints page
      setLocation('/user-dashboard/track');
      
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit complaint",
        variant: "destructive"
      });
      console.error("Submit error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-xl font-medium text-gray-800">Report a Cleanliness Issue</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Column - Form Fields */}
            <div className="space-y-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Issue Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="e.g., Garbage pile on roadside"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows="4"
                  placeholder="Please provide more details about the issue..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  required
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upload Image
                </label>
                <div className="mt-1 flex items-center">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current.click()}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  >
                    <i className="fas fa-camera mr-2"></i>
                    Select Image
                  </button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                  <span className="ml-2 text-sm text-gray-500">
                    {formData.image ? formData.image.name : "No file selected"}
                  </span>
                </div>
                
                {/* Image Preview */}
                {previewUrl && (
                  <div className="mt-3">
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="h-32 w-auto object-cover rounded-md"
                    />
                  </div>
                )}
              </div>
            </div>
            
            {/* Right Column - Location */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Location <span className="text-red-500">*</span>
                </label>
                <div className="flex mb-2">
                  <input
                    type="text"
                    value={addressInput}
                    onChange={(e) => setAddressInput(e.target.value)}
                    placeholder="Enter address or search on map"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddressSearch}
                    disabled={loading}
                    className="px-4 py-2 bg-green-600 text-white rounded-r-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                  >
                    {loading ? (
                      <i className="fas fa-spinner fa-spin"></i>
                    ) : (
                      <i className="fas fa-search"></i>
                    )}
                  </button>
                </div>
                
                <div className="h-[300px] bg-gray-100 rounded-md overflow-hidden">
                  <GoogleMapComponent
                    center={selectedLocation}
                    markers={selectedLocation ? [{ ...selectedLocation, status: 'pending' }] : []}
                    onMapClick={handleMapClick}
                    selectable={true}
                    height="300px"
                  />
                </div>
                
                {/* Hidden inputs to store latitude and longitude */}
                <input type="hidden" name="latitude" value={formData.latitude} />
                <input type="hidden" name="longitude" value={formData.longitude} />
                
                {formData.location && (
                  <div className="mt-2 text-sm text-gray-600">
                    <i className="fas fa-map-marker-alt text-green-600 mr-1"></i>
                    {formData.location}
                  </div>
                )}
              </div>
              
              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setLocation('/user-dashboard')}
                  className="mr-3 px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-paper-plane mr-2"></i>
                      Submit Complaint
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
      
      <div className="bg-green-50 rounded-lg p-4 mt-6">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="fas fa-lightbulb text-green-600 text-xl"></i>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-800">Tips for effective reporting</h3>
            <div className="mt-2 text-sm text-green-700">
              <ul className="list-disc pl-5 space-y-1">
                <li>Be specific in your description</li>
                <li>Include clear photos that show the issue</li>
                <li>Make sure the location is accurate</li>
                <li>Mention any potential health or safety concerns</li>
                <li>Avoid duplicate reports - check if someone already reported the issue</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplaintForm;
