import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../../../hooks/useAuth';
import { apiRequest } from '../../../lib/queryClient';

const StatCard = ({ icon, title, value, color, trend = null }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center">
        <div className={`bg-${color}-100 p-3 rounded-full`}>
          <i className={`fas ${icon} text-${color}-600`}></i>
        </div>
        <div className="ml-4">
          <h3 className="text-gray-500 text-sm">{title}</h3>
          <div className="flex items-center">
            <p className="text-2xl font-semibold text-gray-800">{value}</p>
            {trend && (
              <span className={`ml-2 text-sm ${trend.type === 'increase' ? 'text-green-500' : 'text-red-500'}`}>
                <i className={`fas fa-arrow-${trend.type === 'increase' ? 'up' : 'down'} mr-1`}></i>
                {trend.value}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const AdminDashboardHome = () => {
  const { user } = useAuth();
  
  // Fetch data from API
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: () => apiRequest('GET', '/api/users').then(res => res.json())
  });
  
  const { data: complaints = [], isLoading: complaintsLoading } = useQuery({
    queryKey: ['/api/complaints'],
    queryFn: () => apiRequest('GET', '/api/complaints').then(res => res.json())
  });
  
  const { data: collaborations = [], isLoading: collaborationsLoading } = useQuery({
    queryKey: ['/api/collaborations'],
    queryFn: () => apiRequest('GET', '/api/collaborations').then(res => res.json())
  });

  // Derived stats
  const citizenUsers = users.filter(u => u.userType === 'user').length;
  const officialUsers = users.filter(u => u.userType === 'official').length;
  const pendingComplaints = complaints.filter(c => c.status === 'pending').length;
  const inProgressComplaints = complaints.filter(c => c.status === 'in-progress').length;
  const resolvedComplaints = complaints.filter(c => c.status === 'resolved').length;
  
  // Recent complaints for display
  const recentComplaints = complaints
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);
  
  // Active officials with most resolved complaints
  const officialStats = users
    .filter(user => user.userType === 'official')
    .map(official => {
      const resolvedByOfficial = complaints.filter(c => 
        c.officialId === official.id && c.status === 'resolved'
      ).length;
      
      return {
        id: official.id,
        name: official.fullName || official.username,
        resolved: resolvedByOfficial,
        // Calculate average resolution time (mock data for now)
        avgResolutionTime: '2.3d'
      };
    })
    .sort((a, b) => b.resolved - a.resolved)
    .slice(0, 5);
  
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Welcome, {user?.fullName || user?.username}</h1>
        <p className="text-gray-600">Here's what's happening with the Smart Road Cleanliness system today.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          icon="fa-users" 
          title="Total Citizens" 
          value={citizenUsers} 
          color="blue"
          trend={{ type: 'increase', value: '12%' }}
        />
        <StatCard 
          icon="fa-user-tie" 
          title="Total Officials" 
          value={officialUsers} 
          color="indigo"
        />
        <StatCard 
          icon="fa-clipboard-list" 
          title="Total Complaints" 
          value={complaints.length} 
          color="yellow"
          trend={{ type: 'increase', value: '8%' }}
        />
        <StatCard 
          icon="fa-users-cog" 
          title="Cleanup Events" 
          value={collaborations.length} 
          color="green"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-800">Complaint Status Overview</h2>
          </div>
          <div className="p-6">
            {complaintsLoading ? (
              <div className="text-center py-4">
                <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
                <p className="mt-2 text-gray-600">Loading statistics...</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-yellow-500 text-3xl font-bold">{pendingComplaints}</div>
                    <div className="text-gray-500 text-sm mt-1">Pending</div>
                  </div>
                  <div className="text-center">
                    <div className="text-blue-500 text-3xl font-bold">{inProgressComplaints}</div>
                    <div className="text-gray-500 text-sm mt-1">In Progress</div>
                  </div>
                  <div className="text-center">
                    <div className="text-green-500 text-3xl font-bold">{resolvedComplaints}</div>
                    <div className="text-gray-500 text-sm mt-1">Resolved</div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <div className="relative pt-1">
                    <div className="flex mb-2 items-center justify-between">
                      <div>
                        <span className="text-xs font-semibold inline-block text-gray-600">
                          Resolution Rate: {complaints.length > 0 ? Math.round((resolvedComplaints / complaints.length) * 100) : 0}%
                        </span>
                      </div>
                    </div>
                    <div className="flex h-2 overflow-hidden text-xs bg-gray-200 rounded">
                      <div 
                        style={{ width: `${complaints.length > 0 ? Math.round((resolvedComplaints / complaints.length) * 100) : 0}%` }} 
                        className="flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                      ></div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 text-right">
                  <Link href="/admin-dashboard/complaints">
                    <a className="text-green-600 hover:text-green-700 text-sm font-medium">
                      View All Complaints
                    </a>
                  </Link>
                </div>
              </>
            )}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-800">System Health</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Server Load</span>
                  <span className="text-sm font-medium text-gray-700">15%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '15%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Database Usage</span>
                  <span className="text-sm font-medium text-gray-700">42%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '42%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Storage Usage</span>
                  <span className="text-sm font-medium text-gray-700">28%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '28%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">API Response Time</span>
                  <span className="text-sm font-medium text-gray-700">230ms</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '23%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="mt-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                <span className="inline-flex items-center text-green-600">
                  <i className="fas fa-check-circle mr-1"></i> All systems operational
                </span>
              </div>
              <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                View Details
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-800">Recent Complaints</h2>
          </div>
          <div className="p-6">
            {complaintsLoading ? (
              <div className="text-center py-4">
                <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
                <p className="mt-2 text-gray-600">Loading complaints...</p>
              </div>
            ) : recentComplaints.length > 0 ? (
              <div className="space-y-4">
                {recentComplaints.map(complaint => (
                  <div key={complaint.id} className="flex items-start">
                    <div className="flex-shrink-0">
                      <img 
                        className="h-10 w-10 rounded-md object-cover" 
                        src={complaint.imageUrl || "https://via.placeholder.com/40?text=No+Image"} 
                        alt={complaint.title} 
                      />
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-gray-900">{complaint.title}</h4>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          complaint.status === 'pending' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : complaint.status === 'in-progress' 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-green-100 text-green-800'
                        }`}>
                          {complaint.status.charAt(0).toUpperCase() + complaint.status.slice(1)}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">{complaint.location}</p>
                      <p className="mt-1 text-xs text-gray-500">
                        {new Date(complaint.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-600">No complaints found</p>
              </div>
            )}
            
            <div className="mt-4 text-right">
              <Link href="/admin-dashboard/complaints">
                <a className="text-green-600 hover:text-green-700 text-sm font-medium">
                  View All Complaints
                </a>
              </Link>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-800">Top Performing Officials</h2>
          </div>
          <div className="p-6">
            {usersLoading || complaintsLoading ? (
              <div className="text-center py-4">
                <i className="fas fa-circle-notch fa-spin text-green-600 text-2xl"></i>
                <p className="mt-2 text-gray-600">Loading officials data...</p>
              </div>
            ) : officialStats.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Official</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resolved</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg. Time</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {officialStats.map((official, index) => (
                      <tr key={official.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-8 w-8 bg-gray-200 rounded-full flex items-center justify-center">
                              <span className="text-xs font-medium text-gray-600">{index + 1}</span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{official.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{official.resolved}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{official.avgResolutionTime}</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-600">No officials data available</p>
              </div>
            )}
            
            <div className="mt-4 text-right">
              <Link href="/admin-dashboard/officials">
                <a className="text-green-600 hover:text-green-700 text-sm font-medium">
                  View All Officials
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardHome;
