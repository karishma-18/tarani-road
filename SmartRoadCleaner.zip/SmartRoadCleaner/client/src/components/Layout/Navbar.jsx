import { useState } from 'react';
import { Link } from 'wouter';
import { useAuth } from '../../hooks/useAuth';
import AuthModal from '../Auth/AuthModal';

const Navbar = () => {
  const { user, logout } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <>
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <i className="text-green-700 text-3xl mr-2 fas fa-leaf"></i>
                <span className="font-semibold text-xl text-green-700">Smart Road Cleanliness</span>
              </div>
            </div>
            <div className="flex items-center">
              <div className="hidden md:ml-6 md:flex md:space-x-8">
                <Link href="/">
                  <a className="text-green-700 border-green-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                    Home
                  </a>
                </Link>
                <Link href="/#about">
                  <a className="border-transparent text-gray-600 hover:text-green-700 hover:border-green-600 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                    About
                  </a>
                </Link>
                <Link href="/#contact">
                  <a className="border-transparent text-gray-600 hover:text-green-700 hover:border-green-600 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                    Contact
                  </a>
                </Link>
                <Link href="/#faq">
                  <a className="border-transparent text-gray-600 hover:text-green-700 hover:border-green-600 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                    FAQ
                  </a>
                </Link>
              </div>
            </div>
            <div className="flex items-center">
              {user ? (
                <div className="flex items-center space-x-4">
                  <Link href={`/${user.userType}-dashboard`}>
                    <a className="text-green-600 hover:text-green-800 font-medium">Dashboard</a>
                  </Link>
                  <button 
                    onClick={logout}
                    className="bg-white text-green-600 border border-green-600 hover:bg-green-50 font-medium py-2 px-4 rounded-md transition-all">
                    Logout
                  </button>
                </div>
              ) : (
                <button 
                  onClick={openModal}
                  className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition-all">
                  Login / Sign Up
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <AuthModal isOpen={isModalOpen} onClose={closeModal} />
    </>
  );
};

export default Navbar;
