import { Link } from 'wouter';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center">
              <i className="text-green-500 text-3xl mr-2 fas fa-leaf"></i>
              <span className="text-xl font-bold">Smart Road Cleanliness</span>
            </div>
            <p className="mt-4 text-gray-400">
              Connecting citizens and municipal authorities for a cleaner, greener city.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Resources</h3>
            <ul className="mt-4 space-y-4">
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Documentation</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Guides</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">FAQ</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Company</h3>
            <ul className="mt-4 space-y-4">
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">About</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Contact</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Careers</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Legal</h3>
            <ul className="mt-4 space-y-4">
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Privacy Policy</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Terms of Service</a></Link></li>
              <li><Link href="/"><a className="text-base text-gray-300 hover:text-white transition-all">Cookie Policy</a></Link></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white">
              <span className="sr-only">Facebook</span>
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <span className="sr-only">Twitter</span>
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <span className="sr-only">Instagram</span>
              <i className="fab fa-instagram"></i>
            </a>
          </div>
          <p className="mt-8 text-base text-gray-400 md:mt-0">
            &copy; {new Date().getFullYear()} Smart Road Cleanliness. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
