import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '../../hooks/useAuth';
import { AnimatePresence, motion } from 'framer-motion';

const UserSidebarItems = [
  { name: 'Dashboard', path: '/user-dashboard', icon: 'fa-tachometer-alt' },
  { name: 'Profile', path: '/user-dashboard/profile', icon: 'fa-user' },
  { name: 'About Us', path: '/user-dashboard/about', icon: 'fa-info-circle' },
  { name: 'New Complaint', path: '/user-dashboard/new-complaint', icon: 'fa-plus-circle' },
  { name: 'Track Complaints', path: '/user-dashboard/track', icon: 'fa-history' },
  { name: 'Collaborate', path: '/user-dashboard/collaborate', icon: 'fa-users' },
  { name: 'Rewards', path: '/user-dashboard/rewards', icon: 'fa-trophy' },
  { name: 'Road Ratings', path: '/user-dashboard/ratings', icon: 'fa-star' },
];

const OfficialSidebarItems = [
  { name: 'Dashboard', path: '/official-dashboard', icon: 'fa-tachometer-alt' },
  { name: 'Profile', path: '/official-dashboard/profile', icon: 'fa-user' },
  { name: 'View Complaints', path: '/official-dashboard/complaints', icon: 'fa-clipboard-list' },
  { name: 'Update Status', path: '/official-dashboard/update-status', icon: 'fa-tasks' },
  { name: 'Maps', path: '/official-dashboard/maps', icon: 'fa-map-marked-alt' },
  { name: 'Ratings & Reviews', path: '/official-dashboard/ratings', icon: 'fa-star' },
  { name: 'Reports', path: '/official-dashboard/reports', icon: 'fa-chart-bar' },
];

const AdminSidebarItems = [
  { name: 'Dashboard', path: '/admin-dashboard', icon: 'fa-tachometer-alt' },
  { name: 'Manage Users', path: '/admin-dashboard/users', icon: 'fa-users-cog' },
  { name: 'Manage Officials', path: '/admin-dashboard/officials', icon: 'fa-user-tie' },
  { name: 'All Complaints', path: '/admin-dashboard/complaints', icon: 'fa-clipboard-list' },
  { name: 'Hot Zones', path: '/admin-dashboard/hot-zones', icon: 'fa-fire' },
  { name: 'Analytics', path: '/admin-dashboard/analytics', icon: 'fa-chart-line' },
  { name: 'Reports', path: '/admin-dashboard/reports', icon: 'fa-file-alt' },
];

const Sidebar = ({ userType = 'user' }) => {
  const [location] = useLocation();
  const { logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  let sidebarItems;
  if (userType === 'official') {
    sidebarItems = OfficialSidebarItems;
  } else if (userType === 'admin') {
    sidebarItems = AdminSidebarItems;
  } else {
    sidebarItems = UserSidebarItems;
  }

  return (
    <>
      <button
        className="md:hidden fixed top-4 left-4 z-30 bg-green-600 text-white p-2 rounded-md"
        onClick={toggleSidebar}
      >
        <i className="fas fa-bars"></i>
      </button>

      <AnimatePresence>
        {(collapsed && window.innerWidth < 768) ? null : (
          <motion.div
            initial={{ x: window.innerWidth < 768 ? -280 : 0 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="w-64 bg-green-800 text-white shadow-md min-h-screen fixed z-20 md:relative"
          >
            <div className="p-6 flex items-center">
              <i className="fas fa-leaf text-white text-3xl mr-2"></i>
              <span className="font-semibold text-lg">Cleanliness Tracker</span>
              {window.innerWidth < 768 && (
                <button
                  className="ml-auto text-white"
                  onClick={toggleSidebar}
                >
                  <i className="fas fa-times"></i>
                </button>
              )}
            </div>

            <nav className="mt-6">
              <div className="px-4">
                <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">General</p>
                {sidebarItems.slice(0, 3).map((item) => (
                  <Link key={item.path} href={item.path}>
                    <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === item.path
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className={`fas ${item.icon} mr-3`}></i>
                      <span>{item.name}</span>
                    </a>
                  </Link>
                ))}
              </div>

              {userType === 'user' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Complaints</p>
                  <Link href="/user-dashboard/new-complaint">
                    <a className={`mt-4 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === '/user-dashboard/new-complaint'
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className="fas fa-plus-circle mr-3"></i>
                      <span>New Complaint</span>
                    </a>
                  </Link>
                  <Link href="/user-dashboard/track">
                    <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === '/user-dashboard/track'
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className="fas fa-history mr-3"></i>
                      <span>Track Complaints</span>
                    </a>
                  </Link>
                </div>
              )}

              {userType === 'user' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Community</p>
                  <Link href="/user-dashboard/collaborate">
                    <a className={`mt-4 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === '/user-dashboard/collaborate'
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className="fas fa-users mr-3"></i>
                      <span>Collaborate</span>
                    </a>
                  </Link>
                  <Link href="/user-dashboard/rewards">
                    <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === '/user-dashboard/rewards'
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className="fas fa-trophy mr-3"></i>
                      <span>Rewards</span>
                    </a>
                  </Link>
                  <Link href="/user-dashboard/ratings">
                    <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                      location === '/user-dashboard/ratings'
                        ? 'text-white bg-green-600 bg-opacity-25'
                        : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                    }`}>
                      <i className="fas fa-star mr-3"></i>
                      <span>Rate Roads</span>
                    </a>
                  </Link>
                </div>
              )}

              {userType === 'official' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Work Management</p>
                  {sidebarItems.slice(2, 5).map((item) => (
                    <Link key={item.path} href={item.path}>
                      <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                        location === item.path
                          ? 'text-white bg-green-600 bg-opacity-25'
                          : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                      }`}>
                        <i className={`fas ${item.icon} mr-3`}></i>
                        <span>{item.name}</span>
                      </a>
                    </Link>
                  ))}
                </div>
              )}

              {userType === 'official' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Performance</p>
                  {sidebarItems.slice(5).map((item) => (
                    <Link key={item.path} href={item.path}>
                      <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                        location === item.path
                          ? 'text-white bg-green-600 bg-opacity-25'
                          : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                      }`}>
                        <i className={`fas ${item.icon} mr-3`}></i>
                        <span>{item.name}</span>
                      </a>
                    </Link>
                  ))}
                </div>
              )}

              {userType === 'admin' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Management</p>
                  {sidebarItems.slice(1, 4).map((item) => (
                    <Link key={item.path} href={item.path}>
                      <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                        location === item.path
                          ? 'text-white bg-green-600 bg-opacity-25'
                          : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                      }`}>
                        <i className={`fas ${item.icon} mr-3`}></i>
                        <span>{item.name}</span>
                      </a>
                    </Link>
                  ))}
                </div>
              )}

              {userType === 'admin' && (
                <div className="px-4 mt-6">
                  <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider">Analytics</p>
                  {sidebarItems.slice(4).map((item) => (
                    <Link key={item.path} href={item.path}>
                      <a className={`mt-2 flex items-center py-2 px-2 rounded-md transition-all ${
                        location === item.path
                          ? 'text-white bg-green-600 bg-opacity-25'
                          : 'text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25'
                      }`}>
                        <i className={`fas ${item.icon} mr-3`}></i>
                        <span>{item.name}</span>
                      </a>
                    </Link>
                  ))}
                </div>
              )}

              <div className="px-4 mt-10">
                <button
                  onClick={logout}
                  className="flex items-center py-2 px-2 text-gray-300 hover:text-white hover:bg-green-600 hover:bg-opacity-25 rounded-md transition-all w-full"
                >
                  <i className="fas fa-sign-out-alt mr-3"></i>
                  <span>Logout</span>
                </button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {collapsed && window.innerWidth < 768 && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10"
          onClick={toggleSidebar}
        />
      )}
    </>
  );
};

export default Sidebar;
