import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ChatbotMessage = ({ message, type }) => {
  return (
    <div className={`flex items-start ${type === 'bot' ? '' : 'justify-end'}`}>
      {type === 'bot' && (
        <div className="flex-shrink-0 bg-green-100 rounded-full p-2">
          <i className="fas fa-robot text-green-700 text-sm"></i>
        </div>
      )}
      <div className={`ml-3 py-2 px-3 rounded-lg max-w-[85%] ${
        type === 'bot' ? 'bg-gray-100 text-gray-800' : 'bg-green-600 text-white'
      }`}>
        <p className="text-sm">{message}</p>
      </div>
    </div>
  );
};

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hello! I'm your Cleanliness Assistant. How can I help you today?", type: 'bot' }
  ]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef(null);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { text: inputText, type: 'user' }]);
    
    // Simulate bot response after a short delay
    setTimeout(() => {
      let response;
      const lowercaseInput = inputText.toLowerCase();
      
      if (lowercaseInput.includes('complaint') || lowercaseInput.includes('report')) {
        response = "To report a complaint, go to the user dashboard and click on 'New Complaint'. You'll need to upload an image of the issue and mark the location on the map.";
      } else if (lowercaseInput.includes('track') || lowercaseInput.includes('status')) {
        response = "You can track your complaints in the 'Track Complaints' section of your dashboard. You'll see updates as municipal officials process your report.";
      } else if (lowercaseInput.includes('reward') || lowercaseInput.includes('point')) {
        response = "You earn points each time you report a valid issue. These points appear on your profile and contribute to your ranking on the leaderboard.";
      } else if (lowercaseInput.includes('collaborate') || lowercaseInput.includes('volunteer')) {
        response = "You can join or create cleanup drives through the 'Collaborate' section. This helps you connect with other citizens who want to improve your community.";
      } else if (lowercaseInput.includes('rating') || lowercaseInput.includes('feedback')) {
        response = "After a complaint is resolved, you can rate the work quality. This helps us improve our services and recognize good performers.";
      } else if (lowercaseInput.includes('thank')) {
        response = "You're welcome! I'm here to help anytime you need assistance.";
      } else if (lowercaseInput.includes('hello') || lowercaseInput.includes('hi')) {
        response = "Hello! How can I assist you with the Smart Road Cleanliness Tracker today?";
      } else {
        response = "I'm not sure I understand that question. Could you try rephrasing, or ask about reporting complaints, tracking status, rewards, collaboration, or ratings?";
      }
      
      setMessages(prev => [...prev, { text: response, type: 'bot' }]);
    }, 1000);
    
    // Clear input
    setInputText('');
  };

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-white rounded-lg shadow-lg w-80 mb-4 max-h-96 overflow-hidden flex flex-col"
          >
            <div className="bg-green-700 text-white py-3 px-4 flex justify-between items-center">
              <div className="flex items-center">
                <i className="fas fa-headset mr-2"></i>
                <h3 className="font-medium">Cleanliness Assistant</h3>
              </div>
              <button 
                onClick={toggleChatbot}
                className="text-white focus:outline-none hover:text-gray-200 transition-colors"
              >
                <i className="fas fa-minus"></i>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4" style={{ maxHeight: '300px' }}>
              {messages.map((msg, index) => (
                <ChatbotMessage key={index} message={msg.text} type={msg.type} />
              ))}
              <div ref={messagesEndRef} />
            </div>
            <div className="border-t p-3">
              <form className="flex items-center" onSubmit={handleSubmit}>
                <input 
                  type="text" 
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-green-600 focus:border-green-600" 
                  placeholder="Type your message..." 
                />
                <button 
                  type="submit" 
                  className="bg-green-600 hover:bg-green-700 text-white rounded-r-md p-2 focus:outline-none transition-all"
                >
                  <i className="fas fa-paper-plane text-sm"></i>
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <motion.button 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleChatbot} 
        className="bg-green-600 hover:bg-green-700 w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white focus:outline-none transition-all"
      >
        <i className={`fas ${isOpen ? 'fa-times' : 'fa-comment'}`}></i>
      </motion.button>
    </div>
  );
};

export default Chatbot;
