import { useState, useEffect } from 'react';
import { useMaps } from '../../hooks/useMaps';

const GoogleMapComponent = ({ 
  markers = [], 
  center, 
  defaultZoom = 10, 
  height = '100%',
  onMapClick, 
  selectable = false 
}) => {
  const { isLoaded, loadError } = useMaps();
  const [map, setMap] = useState(null);
  const [mapMarkers, setMapMarkers] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  
  // Get user's location for default center if not provided
  useEffect(() => {
    if (!center && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setSelectedLocation({ lat: latitude, lng: longitude });
        },
        () => {
          // Default coordinates if geolocation fails (center of map)
          setSelectedLocation({ lat: 20.5937, lng: 78.9629 }); // Center of India
        }
      );
    } else if (center) {
      setSelectedLocation(center);
    }
  }, [center]);

  // Initialize map when Google Maps is loaded
  useEffect(() => {
    if (isLoaded && !loadError && selectedLocation) {
      const mapInstance = new window.google.maps.Map(document.getElementById('map'), {
        center: selectedLocation,
        zoom: defaultZoom,
        streetViewControl: false,
        mapTypeControl: false,
        fullscreenControl: true,
        zoomControl: true,
      });
      
      setMap(mapInstance);
      
      // Add click listener if map is selectable
      if (selectable) {
        mapInstance.addListener('click', (e) => {
          const clickedLocation = {
            lat: e.latLng.lat(),
            lng: e.latLng.lng()
          };
          
          setSelectedLocation(clickedLocation);
          
          if (onMapClick) {
            onMapClick(clickedLocation);
          }
          
          // Clear existing markers
          mapMarkers.forEach(marker => marker.setMap(null));
          
          // Add a marker at clicked location
          const marker = new window.google.maps.Marker({
            position: clickedLocation,
            map: mapInstance,
            animation: window.google.maps.Animation.DROP,
          });
          
          setMapMarkers([marker]);
        });
      }
    }
  }, [isLoaded, loadError, selectedLocation, selectable, onMapClick, defaultZoom]);

  // Update markers on the map
  useEffect(() => {
    if (map && markers.length > 0) {
      // Clear existing markers
      mapMarkers.forEach(marker => marker.setMap(null));
      
      const bounds = new window.google.maps.LatLngBounds();
      const newMarkers = markers.map(markerData => {
        const position = { 
          lat: markerData.lat, 
          lng: markerData.lng 
        };
        
        bounds.extend(position);
        
        // Determine icon color based on status
        let iconColor = 'red';
        if (markerData.status === 'in-progress') {
          iconColor = 'yellow';
        } else if (markerData.status === 'resolved') {
          iconColor = 'green';
        }
        
        const marker = new window.google.maps.Marker({
          position,
          map,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            fillColor: iconColor,
            fillOpacity: 0.6,
            strokeWeight: 1,
            strokeColor: '#ffffff',
            scale: 10,
          },
          title: markerData.title || 'Complaint'
        });
        
        if (markerData.info) {
          const infoWindow = new window.google.maps.InfoWindow({
            content: markerData.info
          });
          
          marker.addListener('click', () => {
            infoWindow.open(map, marker);
          });
        }
        
        return marker;
      });
      
      setMapMarkers(newMarkers);
      
      // Fit map to show all markers if there are multiple
      if (markers.length > 1) {
        map.fitBounds(bounds);
      }
    }
  }, [map, markers]);

  if (loadError) {
    return (
      <div className="flex items-center justify-center bg-gray-100 rounded-lg" style={{ height }}>
        <div className="text-center p-4">
          <div className="text-red-500 text-xl mb-2">
            <i className="fas fa-exclamation-triangle"></i>
          </div>
          <p>Error loading Google Maps</p>
          <p className="text-sm text-gray-500 mt-1">Please check your internet connection and try again</p>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center bg-gray-100 rounded-lg" style={{ height }}>
        <div className="text-center">
          <div className="text-green-600 mb-2">
            <i className="fas fa-circle-notch fa-spin text-2xl"></i>
          </div>
          <p>Loading map...</p>
        </div>
      </div>
    );
  }

  return (
    <div id="map" style={{ height, width: '100%' }} className="rounded-lg"></div>
  );
};

export default GoogleMapComponent;
