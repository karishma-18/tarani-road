import { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

const SignupForm = ({ onClose }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
    userType: 'user'
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const { register } = useAuth();
  const { toast } = useToast();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Form validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone || !formData.password || !formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive"
      });
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Passwords do not match",
        variant: "destructive"
      });
      return;
    }
    
    if (!formData.agreeTerms) {
      toast({
        title: "Error",
        description: "You must agree to the terms and conditions",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      await register({
        fullName: `${formData.firstName} ${formData.lastName}`,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        userType: formData.userType
      });
      
      toast({
        title: "Success",
        description: "Your account has been created successfully",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to create account",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">First name</label>
          <div className="mt-1">
            <input 
              id="first-name" 
              name="firstName" 
              type="text" 
              value={formData.firstName}
              onChange={handleChange}
              autoComplete="given-name" 
              required 
              className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
            />
          </div>
        </div>
        
        <div>
          <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">Last name</label>
          <div className="mt-1">
            <input 
              id="last-name" 
              name="lastName" 
              type="text"
              value={formData.lastName}
              onChange={handleChange}
              autoComplete="family-name" 
              required 
              className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
            />
          </div>
        </div>
      </div>
      
      <div>
        <label htmlFor="signup-email" className="block text-sm font-medium text-gray-700">Email address</label>
        <div className="mt-1">
          <input 
            id="signup-email" 
            name="email" 
            type="email"
            value={formData.email}
            onChange={handleChange}
            autoComplete="email" 
            required 
            className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
          />
        </div>
      </div>
      
      <div>
        <label htmlFor="signup-phone" className="block text-sm font-medium text-gray-700">Phone number</label>
        <div className="mt-1">
          <input 
            id="signup-phone" 
            name="phone" 
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            autoComplete="tel" 
            required 
            className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
          />
        </div>
      </div>
      
      <div>
        <label htmlFor="signup-password" className="block text-sm font-medium text-gray-700">Password</label>
        <div className="mt-1 relative">
          <input 
            id="signup-password" 
            name="password" 
            type={showPassword ? "text" : "password"}
            value={formData.password}
            onChange={handleChange}
            autoComplete="new-password" 
            required 
            className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
          />
          <button 
            type="button" 
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
            onClick={() => setShowPassword(!showPassword)}
          >
            <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'} text-gray-400 text-xl`}></i>
          </button>
        </div>
      </div>
      
      <div>
        <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700">Confirm password</label>
        <div className="mt-1 relative">
          <input 
            id="confirm-password" 
            name="confirmPassword" 
            type={showConfirmPassword ? "text" : "password"}
            value={formData.confirmPassword}
            onChange={handleChange}
            autoComplete="new-password" 
            required 
            className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-600 focus:border-green-600 sm:text-sm"
          />
          <button 
            type="button" 
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          >
            <i className={`fas ${showConfirmPassword ? 'fa-eye-slash' : 'fa-eye'} text-gray-400 text-xl`}></i>
          </button>
        </div>
      </div>
      
      <div className="flex items-center">
        <input 
          id="agree-terms" 
          name="agreeTerms" 
          type="checkbox"
          checked={formData.agreeTerms}
          onChange={handleChange}
          className="h-4 w-4 text-green-600 focus:ring-green-600 border-gray-300 rounded" 
          required
        />
        <label htmlFor="agree-terms" className="ml-2 block text-sm text-gray-700">
          I agree to the <a href="#" className="text-green-700 hover:text-green-500">Terms and Conditions</a>
        </label>
      </div>
      
      <div>
        <button 
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Creating account...
            </>
          ) : "Sign up"}
        </button>
      </div>
      
      <div className="text-sm text-center">
        <span>Register as: </span>
        <button 
          type="button" 
          onClick={() => setFormData(prev => ({ ...prev, userType: 'user' }))} 
          className={`font-medium ml-1 ${formData.userType === 'user' ? 'text-green-700' : 'text-green-600 hover:text-green-700'}`}
        >
          User
        </button> | 
        <button 
          type="button" 
          onClick={() => setFormData(prev => ({ ...prev, userType: 'official' }))} 
          className={`font-medium ml-1 ${formData.userType === 'official' ? 'text-green-700' : 'text-green-600 hover:text-green-700'}`}
        >
          Official
        </button>
      </div>
    </form>
  );
};

export default SignupForm;
