import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import LoginForm from './LoginForm';
import SignupForm from './SignupForm';

const backdrop = {
  visible: { opacity: 1 },
  hidden: { opacity: 0 }
};

const modal = {
  hidden: { y: "-100vh", opacity: 0 },
  visible: { 
    y: 0, 
    opacity: 1,
    transition: { delay: 0.1 }
  }
};

const AuthModal = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('login');

  return (
    <AnimatePresence exitBeforeEnter>
      {isOpen && (
        <motion.div 
          className="fixed z-50 inset-0 overflow-y-auto"
          variants={backdrop}
          initial="hidden"
          animate="visible"
          exit="hidden"
        >
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity">
              <div 
                className="absolute inset-0 bg-gray-500 opacity-75" 
                onClick={onClose}
              ></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen"></span>&#8203;
            
            <motion.div
              variants={modal}
              className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"
            >
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                      {activeTab === 'login' ? 'Login to Your Account' : 'Create a New Account'}
                    </h3>
                    <div className="mt-2">
                      {/* Tabs */}
                      <div className="border-b border-gray-200">
                        <nav className="flex -mb-px">
                          <button 
                            onClick={() => setActiveTab('login')}
                            className={`py-4 px-1 border-b-2 font-medium text-sm w-1/2 text-center transition-colors ${
                              activeTab === 'login'
                                ? 'text-green-700 border-green-700'
                                : 'text-gray-500 hover:text-gray-700 border-transparent'
                            }`}
                          >
                            Login
                          </button>
                          <button 
                            onClick={() => setActiveTab('signup')}
                            className={`py-4 px-1 border-b-2 font-medium text-sm w-1/2 text-center transition-colors ${
                              activeTab === 'signup'
                                ? 'text-green-700 border-green-700'
                                : 'text-gray-500 hover:text-gray-700 border-transparent'
                            }`}
                          >
                            Sign Up
                          </button>
                        </nav>
                      </div>
                      
                      {/* Form Content */}
                      <div className="mt-4">
                        {activeTab === 'login' ? (
                          <LoginForm onClose={onClose} />
                        ) : (
                          <SignupForm onClose={onClose} />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button 
                  type="button" 
                  onClick={onClose}
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-600 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AuthModal;
