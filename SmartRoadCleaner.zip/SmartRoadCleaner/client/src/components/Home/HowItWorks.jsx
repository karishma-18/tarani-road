import { motion } from 'framer-motion';

const stepVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: i => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.2,
      duration: 0.5
    }
  })
};

const StepCard = ({ icon, title, description, index }) => {
  return (
    <motion.div 
      className="bg-white p-6 rounded-lg shadow-md max-w-xs w-full text-center transition-all hover:shadow-lg"
      custom={index}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      variants={stepVariants}
      whileHover={{ y: -5 }}
    >
      <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
        <i className={`fas ${icon} text-green-700 text-2xl`}></i>
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">{title}</h3>
      <p className="text-base text-gray-600">{description}</p>
    </motion.div>
  );
};

const HowItWorks = () => {
  const steps = [
    {
      icon: "fa-camera",
      title: "1. Report",
      description: "Take a photo of the issue and mark the location on the map"
    },
    {
      icon: "fa-clipboard-check",
      title: "2. Review",
      description: "Municipal authorities review and assign the complaint"
    },
    {
      icon: "fa-tools",
      title: "3. Resolve",
      description: "Workers clean up the area and mark the work as complete"
    },
    {
      icon: "fa-star",
      title: "4. Rate",
      description: "Rate the quality of work and earn points for your contribution"
    }
  ];

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="lg:text-center mb-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-base text-green-600 font-semibold tracking-wide uppercase">Process</h2>
          <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
            How it works
          </p>
        </motion.div>
        
        <div className="flex flex-col md:flex-row justify-between items-center md:items-start space-y-8 md:space-y-0 md:space-x-4">
          {steps.map((step, index) => (
            <StepCard 
              key={index}
              icon={step.icon}
              title={step.title}
              description={step.description}
              index={index}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
