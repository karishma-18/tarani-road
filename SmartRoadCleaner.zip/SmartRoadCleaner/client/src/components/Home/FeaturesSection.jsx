import { motion } from 'framer-motion';

const featureVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: i => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.2,
      duration: 0.5
    }
  })
};

const FeatureItem = ({ icon, title, description, index }) => {
  return (
    <motion.div 
      className="flex"
      custom={index}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      variants={featureVariants}
    >
      <div className="flex-shrink-0">
        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
          <i className={`fas ${icon}`}></i>
        </div>
      </div>
      <div className="ml-4">
        <h3 className="text-lg leading-6 font-medium text-gray-900">{title}</h3>
        <p className="mt-2 text-base text-gray-600">
          {description}
        </p>
      </div>
    </motion.div>
  );
};

const FeaturesSection = () => {
  const features = [
    {
      icon: "fa-camera",
      title: "Report Issues Easily",
      description: "Take a photo, mark the location on the map, and submit your complaint in just a few taps."
    },
    {
      icon: "fa-map-marked-alt",
      title: "Track Progress",
      description: "Follow the status of your complaints and see how quickly issues are being resolved."
    },
    {
      icon: "fa-users",
      title: "Community Collaboration",
      description: "Form volunteer groups to organize cleanup drives in your neighborhood."
    },
    {
      icon: "fa-award",
      title: "Rewards & Recognition",
      description: "Earn points, certificates, and recognition for your contribution to a cleaner city."
    }
  ];

  return (
    <div id="features" className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="lg:text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-base text-green-600 font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
            A better way to keep our city clean
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-600 lg:mx-auto">
            Our platform offers innovative solutions to connect citizens and authorities for a cleaner environment.
          </p>
        </motion.div>

        <div className="mt-10">
          <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
            {features.map((feature, index) => (
              <FeatureItem 
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                index={index}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturesSection;
