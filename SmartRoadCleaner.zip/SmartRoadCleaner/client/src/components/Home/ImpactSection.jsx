import { motion } from 'framer-motion';

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: i => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.2,
      duration: 0.5
    }
  })
};

const ImpactCard = ({ image, statValue, statLabel, description, index }) => {
  return (
    <motion.div 
      className="bg-gray-50 overflow-hidden rounded-lg shadow-sm hover:shadow-md transition-all"
      custom={index}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      variants={cardVariants}
      whileHover={{ y: -5 }}
    >
      <img className="h-48 w-full object-cover" src={image} alt={statLabel} />
      <div className="p-6">
        <div className="flex items-center">
          <span className="flex-shrink-0 inline-block h-10 w-10 rounded-full bg-green-700 text-white flex items-center justify-center">
            <span className="text-xl font-bold">{statValue}</span>
          </span>
          <h3 className="ml-4 text-lg font-medium text-gray-900">{statLabel}</h3>
        </div>
        <p className="mt-3 text-base text-gray-600">{description}</p>
      </div>
    </motion.div>
  );
};

const ImpactSection = () => {
  const impactStats = [
    {
      image: "https://images.unsplash.com/photo-1604480133435-25b86862d276?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      statValue: "5K+",
      statLabel: "Complaints Resolved",
      description: "Over 5,000 cleanliness issues resolved across the city since launch."
    },
    {
      image: "https://images.unsplash.com/photo-1509099836639-18ba1795216d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80",
      statValue: "350+",
      statLabel: "Volunteer Groups",
      description: "More than 350 community volunteer groups formed for local cleanup drives."
    },
    {
      image: "https://images.unsplash.com/photo-1565186829484-1faedfdb36bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      statValue: "90%",
      statLabel: "User Satisfaction",
      description: "90% of users report satisfaction with the resolution of their complaints."
    }
  ];

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="lg:text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-base text-green-600 font-semibold tracking-wide uppercase">Impact</h2>
          <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
            Making a difference together
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-600 lg:mx-auto">
            See how our initiative is transforming communities across the city.
          </p>
        </motion.div>
        
        <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {impactStats.map((stat, index) => (
            <ImpactCard 
              key={index}
              image={stat.image}
              statValue={stat.statValue}
              statLabel={stat.statLabel}
              description={stat.description}
              index={index}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImpactSection;
